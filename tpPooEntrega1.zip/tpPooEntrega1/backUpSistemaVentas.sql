-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: bd_sistemaventas
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_categorias`
--

DROP TABLE IF EXISTS `tb_categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_categorias` (
  `idCategoria` int NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(250) NOT NULL,
  `estado` int NOT NULL,
  PRIMARY KEY (`idCategoria`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_categorias`
--

LOCK TABLES `tb_categorias` WRITE;
/*!40000 ALTER TABLE `tb_categorias` DISABLE KEYS */;
INSERT INTO `tb_categorias` VALUES (4,'Panes',1),(5,'lacteos',1),(8,'Embutidos',1),(9,'Bebidas',1);
/*!40000 ALTER TABLE `tb_categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_cliente`
--

DROP TABLE IF EXISTS `tb_cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_cliente` (
  `idCliente` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `apellido` varchar(30) NOT NULL,
  `dni` int NOT NULL,
  `celular` varchar(15) NOT NULL,
  `domicilio` varchar(30) NOT NULL,
  PRIMARY KEY (`idCliente`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_cliente`
--

LOCK TABLES `tb_cliente` WRITE;
/*!40000 ALTER TABLE `tb_cliente` DISABLE KEYS */;
INSERT INTO `tb_cliente` VALUES (1,'Roxana','Ridao',45222565,'+54223554585','magallanes 501'),(9,'Pedro','Boenla',52555,'44455','benito linch');
/*!40000 ALTER TABLE `tb_cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_detalleventas`
--

DROP TABLE IF EXISTS `tb_detalleventas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_detalleventas` (
  `idDetallePedido` int NOT NULL AUTO_INCREMENT,
  `idPedido` int NOT NULL,
  `idProducto` int NOT NULL,
  `cantidad` int NOT NULL,
  `precioUnitario` double(15,2) NOT NULL,
  `subtotal` double(15,2) NOT NULL,
  `iva` double(15,2) NOT NULL,
  `total` double(15,2) NOT NULL,
  `estado` int NOT NULL,
  PRIMARY KEY (`idDetallePedido`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_detalleventas`
--

LOCK TABLES `tb_detalleventas` WRITE;
/*!40000 ALTER TABLE `tb_detalleventas` DISABLE KEYS */;
INSERT INTO `tb_detalleventas` VALUES (1,1,1,1,1500.50,1500.50,0.00,1500.50,1),(2,2,1,10,1500.50,15005.00,0.00,15005.00,1),(3,3,1,2,1500.50,3001.00,0.00,3001.00,1),(4,4,1,3,1500.50,4501.50,0.00,4501.50,1),(5,5,1,1,1500.50,1500.50,0.00,1500.50,1),(6,6,1,2,1500.50,3001.00,0.00,3001.00,1),(7,7,1,1,1500.50,1500.50,0.00,1500.50,1),(8,8,1,1,1500.50,1500.50,0.00,1500.50,1),(9,9,1,1,1500.50,1500.50,0.00,1500.50,1),(10,10,1,1,1500.50,1500.50,0.00,1500.50,1),(11,11,1,2,1500.50,3001.00,630.21,3631.21,1),(12,12,1,1,1500.50,1500.50,315.10,1815.61,1),(13,13,1,1,1500.50,1500.50,315.10,1815.61,1),(14,14,1,1,1500.50,1500.50,315.10,1815.61,1),(15,15,2,2,1820.00,3640.00,764.40,4404.40,1),(16,15,1,1,1500.50,1500.50,315.10,1815.61,1),(17,16,1,1,1500.50,1500.50,315.10,1815.61,0),(18,16,2,1,1820.00,1820.00,382.20,2202.20,0),(19,17,1,1,1500.50,1500.50,315.10,1815.61,0),(20,18,1,1,1500.50,1500.50,315.10,1815.61,0),(21,19,2,1,1820.00,1820.00,382.20,2202.20,0),(22,20,1,1,1500.50,1500.50,315.10,1815.61,0),(23,21,2,3,1820.00,5460.00,1146.60,6606.60,0),(24,22,2,1,1820.00,1820.00,382.20,2202.20,0),(25,23,2,2,1820.00,3640.00,764.40,4404.40,0),(26,24,2,9,1820.00,16380.00,3439.80,19819.80,0),(27,25,2,1,1820.00,1820.00,382.20,2202.20,0),(28,26,1,1,1500.50,1500.50,315.10,1815.61,0),(29,27,3,2,1820.00,3640.00,764.40,4404.40,0),(30,28,3,2,1820.00,3640.00,764.40,4404.40,0),(31,28,3,2,1820.00,3640.00,764.40,4404.40,0),(32,28,1,2,1500.50,3001.00,630.21,3631.21,0),(33,29,1,1,1500.50,1500.50,315.10,1815.61,0),(34,30,3,5,1820.00,9100.00,1911.00,11011.00,0),(35,31,3,3,1820.00,5460.00,1146.60,6606.60,0),(36,32,1,1,1500.50,1500.50,315.10,1815.61,0),(37,33,3,5,1820.00,9100.00,1911.00,11011.00,0),(38,34,3,2,1820.00,3640.00,764.40,4404.40,0),(39,34,3,2,1820.00,3640.00,764.40,4404.40,0),(40,35,3,2,1820.00,3640.00,764.40,4404.40,0),(41,36,4,1,2550.00,2550.00,0.00,2550.00,0),(42,36,1,3,1500.50,4501.50,0.00,4501.50,0),(43,37,5,1,4500.00,4500.00,945.00,5445.00,0),(44,38,16,10,3200.00,32000.00,8640.00,40640.00,0),(45,38,9,10,1500.00,15000.00,3150.00,18150.00,0),(46,39,3,1,1825.00,1825.00,492.75,2317.75,0),(47,40,5,1,4500.00,4500.00,945.00,5445.00,0);
/*!40000 ALTER TABLE `tb_detalleventas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_productos`
--

DROP TABLE IF EXISTS `tb_productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_productos` (
  `idProductos` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `descripcion` varchar(300) NOT NULL,
  `stock` int NOT NULL,
  `precio` double(15,2) NOT NULL,
  `Idcategoria` int NOT NULL,
  `porcentajeIva` int NOT NULL,
  `estado` int NOT NULL,
  PRIMARY KEY (`idProductos`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_productos`
--

LOCK TABLES `tb_productos` WRITE;
/*!40000 ALTER TABLE `tb_productos` DISABLE KEYS */;
INSERT INTO `tb_productos` VALUES (10,'flauta','pancito',2,2100.00,4,0,1),(13,'yogurt','descremado de litro',10,5000.00,5,11,1),(18,'CocaCola','de litro',50,2300.00,9,21,1);
/*!40000 ALTER TABLE `tb_productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_usuario`
--

DROP TABLE IF EXISTS `tb_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_usuario` (
  `idUsuario` int NOT NULL AUTO_INCREMENT,
  `puesto` varchar(30) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellido` varchar(30) NOT NULL,
  `dni` int NOT NULL,
  `celular` varchar(15) NOT NULL,
  `domicilio` varchar(30) NOT NULL,
  `usuario` varchar(15) NOT NULL,
  `contra` varchar(15) NOT NULL,
  `estado` int NOT NULL,
  PRIMARY KEY (`idUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_usuario`
--

LOCK TABLES `tb_usuario` WRITE;
/*!40000 ALTER TABLE `tb_usuario` DISABLE KEYS */;
INSERT INTO `tb_usuario` VALUES (10,'Gerente','Martina','Palleiro',46348869,'+542235556518','Talcahuano y Dellepiane','Gmartina','1234',1),(19,'Cajero','Noelia','Penela',46448252,'+542236582483','Mogotes 582','Cnoelia','1234',1),(20,'Armador de pedidos','Valentina','Leoz',44558265,'+54223582156','Bogota 558','Avalentina','1234',1);
/*!40000 ALTER TABLE `tb_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_ventas`
--

DROP TABLE IF EXISTS `tb_ventas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_ventas` (
  `idPedido` int NOT NULL AUTO_INCREMENT,
  `idCliente` int NOT NULL,
  `Total` double(15,2) NOT NULL,
  `fechaVenta` date NOT NULL,
  `estado` int NOT NULL,
  PRIMARY KEY (`idPedido`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_ventas`
--

LOCK TABLES `tb_ventas` WRITE;
/*!40000 ALTER TABLE `tb_ventas` DISABLE KEYS */;
INSERT INTO `tb_ventas` VALUES (1,0,1500.50,'2024-09-22',1),(2,0,15005.00,'2024-09-22',0),(3,0,3001.00,'2024-09-22',1),(4,0,4501.50,'2024-09-22',1),(5,0,1500.50,'2024-09-22',1),(6,0,3001.00,'2024-09-22',0),(7,0,1500.50,'2024-09-22',1),(8,0,1500.50,'2024-09-22',1),(9,1,1500.50,'2024-09-22',1),(10,1,1500.50,'2024-09-22',1),(11,1,3631.21,'2024-09-22',1),(12,1,1815.61,'2024-09-22',1),(13,1,1815.61,'2024-09-22',1),(14,1,1815.61,'2024-09-22',1),(15,1,6220.01,'2024-09-22',1),(16,1,4017.81,'2024-09-24',1),(17,1,1815.61,'2024-09-24',1),(18,1,1815.61,'2024-09-24',1),(19,1,2202.20,'2024-09-24',1),(20,1,1815.61,'2024-09-24',1),(21,1,6606.60,'2024-09-24',1),(22,1,4404.40,'2024-09-24',1),(23,1,4404.40,'2024-10-13',1),(24,1,19819.80,'2024-10-13',1),(25,1,2202.20,'2024-10-13',1),(26,1,1815.61,'2024-10-14',1),(27,1,4404.40,'2024-10-14',1),(28,1,12440.01,'2024-10-14',1),(29,1,1815.61,'2024-10-14',1),(30,2,11011.00,'2024-10-15',1),(31,2,6606.60,'2024-10-15',1),(32,2,1815.61,'2024-10-15',1),(33,2,11011.00,'2024-10-15',1),(34,1,8808.80,'2024-10-16',1),(35,3,4404.40,'2024-10-16',0),(36,7,7051.50,'2024-10-20',1),(37,8,5445.00,'2024-10-21',0),(38,9,58790.00,'2024-10-22',1),(39,9,2317.75,'2024-10-22',0),(40,1,5445.00,'2024-10-22',0);
/*!40000 ALTER TABLE `tb_ventas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'bd_sistemaventas'
--

--
-- Dumping routines for database 'bd_sistemaventas'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-22 17:49:09
