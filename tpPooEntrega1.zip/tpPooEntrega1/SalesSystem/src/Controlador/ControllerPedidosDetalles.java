package Controlador;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import modelo.DAOSS.DaoPedidos;
import modelo.Entitys.Cliente;
import modelo.DAOSS.DaoPedidosDetalles;
import modelo.Entitys.Pedido;
import modelo.Entitys.Productos;
import modelo.Entitys.detallePedido;

public class ControllerPedidosDetalles {

    static DaoPedidosDetalles dao = new DaoPedidosDetalles();
    private static int idProducto = 0;
    private static int cantProductoStock = 0;
    private static double precioUnitario = 0.0;
    private static int porcentajeIva;
    private static double iva;

    public static List<String> cargarListaClientes() {
        return dao.cargarCliente();

    }

    public static List<String> cargarListaProductos() {
        return dao.cargarProducto(); 
    }

    public static DefaultTableModel inicializarTablaProductos() {
        DefaultTableModel modeloDatosProductos = new DefaultTableModel();
        modeloDatosProductos.addColumn("N");
        modeloDatosProductos.addColumn("Nombre");
        modeloDatosProductos.addColumn("Cantidad");
        modeloDatosProductos.addColumn("$ unitario");
        modeloDatosProductos.addColumn("Subtotal");
        modeloDatosProductos.addColumn("IVA");
        modeloDatosProductos.addColumn("Total a pagar");
        return modeloDatosProductos;
    }

    public static void listarProductos(ArrayList<detallePedido> listaProductos, DefaultTableModel modeloDatosProductos) {

        modeloDatosProductos.setRowCount(0);
        for (detallePedido p : listaProductos) {
            System.out.println("FOR");
            Object[] fila = {
                listaProductos.indexOf(p) + 1,
                p.getProducto(),
                p.getCantidad(),
                p.getPrecioUnitario(),
                p.getSubtotal(),
                p.getIva(),
                p.getTotal()
            };
            modeloDatosProductos.addRow(fila);
        }
    }

    public static boolean validar(String aValidar) {

        try {
            int num = Integer.parseInt(aValidar);
            return true;

        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static boolean validarDouble(String aValidar) {

        try {
            double num = Double.parseDouble(aValidar);
            return true;

        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static int devolverIdProducto(String productoNombre, int cantidad) {
        Productos producto = DaoPedidosDetalles.obtenerDatosDelProducto(productoNombre, cantidad);
        if (producto != null) {
            idProducto = producto.getIdProducto();

        } else {
            System.out.println("Producto no encontrado.");
        }
        return idProducto;

    }

    public static int devolverStock(String productoNombre, int cantidad) {
        Productos producto = DaoPedidosDetalles.obtenerDatosDelProducto(productoNombre, cantidad);
        if (producto != null) {
            cantProductoStock = producto.getStock();

        } else {
            System.out.println("Producto no encontrado.");
        }
        return cantProductoStock;
    }

    public static int devolverPorcentajeIva(String productoNombre, int cantidad) {
        Productos producto = DaoPedidosDetalles.obtenerDatosDelProducto(productoNombre, cantidad);
        if (producto != null) {
            porcentajeIva = (int) producto.getPorcentajeIva();

        } else {
            System.out.println("Producto no encontrado.");
        }
        return porcentajeIva;

    }

    public static double devolverValor(String productoNombre, int cantidad) {
        Productos producto = DaoPedidosDetalles.obtenerDatosDelProducto(productoNombre, cantidad);
        if (producto != null) {
            precioUnitario = producto.getValor();

        } else {
            System.out.println("Producto no encontrado.");
        }
        return precioUnitario;
    }

    public static double devolverIva(String productoNombre, int cantidad) {
        Productos producto = DaoPedidosDetalles.obtenerDatosDelProducto(productoNombre, cantidad);
        if (producto != null) {
            iva = producto.getIva();

        } else {
            System.out.println("Producto no encontrado.");
        }
        return iva;

    }

    public static double calcularIva(double precio, int porcentajeIva, int cantidad) {

        int pIva = porcentajeIva;
        switch (pIva) {

            case 0 ->
                iva = 0.0;

            case 10 ->
                iva = (precio * cantidad) * 0.105;
            case 11 ->
                iva = (precio * cantidad) * 0.105;
            case 21 ->
                iva = (precio * cantidad) * 0.21;

            case 27 ->
                iva = (precio * cantidad) * 0.27;
            default -> {

            }
        }
        return iva;
    }

    public static void calcularTotal(List<detallePedido> listaProductos, JTextField txtSubtotal, JTextField txtIva, JTextField txtTotal) {
        double subtotalGeneral = 0;
        double ivaGeneral = 0;
        double totalGeneral = 0;

        for (detallePedido elemento : listaProductos) {
            subtotalGeneral += elemento.getSubtotal();
            ivaGeneral += elemento.getIva();
            totalGeneral += elemento.getTotal();
        }

        subtotalGeneral = Math.round(subtotalGeneral * 100) / 100.0;
        ivaGeneral = Math.round(ivaGeneral * 100) / 100.0;
        totalGeneral = Math.round(totalGeneral * 100) / 100.0;

        txtSubtotal.setText(String.valueOf(subtotalGeneral));
        txtIva.setText(String.valueOf(ivaGeneral));
        txtTotal.setText(String.valueOf(totalGeneral));
    }

    public static int obtenerIdClienteDesdeCombo(JComboBox<String> comboBoxCliente) {
        String nombreCompleto = comboBoxCliente.getSelectedItem().toString();
        return DaoPedidosDetalles.obtenerIdCliente(nombreCompleto);
    }

    public static void restarStockProducto(int idProducto, int cantidad) {
        DaoPedidosDetalles.restarStock(idProducto, cantidad);
    }

    public static boolean registrarVenta(JComboBox<String> comboBoxCliente, List<detallePedido> listaProductos, double total) {
        if (comboBoxCliente.equals("Seleccion cliente")) {
            JOptionPane.showMessageDialog(null, "Seleccione un cliente");
            return false;
        }

        if (listaProductos.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione un producto");
            return false;
        }

        Pedido pedido = new Pedido();
        detallePedido detalle = new detallePedido();
        String fechaActual = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
        int idCliente = ControllerPedidosDetalles.obtenerIdClienteDesdeCombo(comboBoxCliente);

        pedido.setIdPedido(0);
        pedido.setIdCliente(idCliente);
        pedido.setTotal(total);
        pedido.setFechaVenta(fechaActual);
        pedido.setEstado(0);

        if (!DaoPedidosDetalles.guardarPedido(pedido)) {
            JOptionPane.showMessageDialog(null, "Error al guardar pedido");
            return false;
        }

        for (detallePedido elemento : listaProductos) {
            detalle.setIdDetallePedido(0);
            detalle.setIdPedido(pedido.getIdPedido());
            detalle.setIdProducto(elemento.getIdProducto());
            detalle.setCantidad(elemento.getCantidad());
            detalle.setPrecioUnitario(elemento.getPrecioUnitario());
            detalle.setSubtotal(elemento.getSubtotal());
            detalle.setIva(elemento.getIva());
            detalle.setTotal(elemento.getTotal());
            detalle.setEstado(0);

            if (!DaoPedidosDetalles.guardarDetalle(detalle)) {
                JOptionPane.showMessageDialog(null, "Error al guardar detalle");
                return false;
            }

            ControllerPedidosDetalles.restarStockProducto(elemento.getIdProducto(), elemento.getCantidad());
        }

        return true;
    }

    public static Cliente buscarCliente(String dni) {
        return DaoPedidosDetalles.buscarClientePorDNI(dni);
    }

    public static void añadirProducto(String combo, String cantidadText, List<detallePedido> listaProductos, JTextField txtSubtotal, JTextField txtIva, JTextField txtTotal) {
        int auxIdDetalle = 0;
        if (combo.equalsIgnoreCase("Seleccione producto:")) {
            JOptionPane.showMessageDialog(null, "Seleccione un producto");
            return;
        }

        if (cantidadText.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingresa la cantidad de productos");
            return;
        }

        boolean validacion = validar(cantidadText);
        if (!validacion) {
            JOptionPane.showMessageDialog(null, "En la cantidad no se admiten caracteres no numéricos");
            return;
        }

        int cantidad = Integer.parseInt(cantidadText);
        if (cantidad <= 0) {
            JOptionPane.showMessageDialog(null, "La cantidad no puede ser cero (0), ni negativa");
            return;
        }

        int idProducto = devolverIdProducto(combo, cantidad);
        String productoNombre = combo;
        int cantProductoStock = devolverStock(combo, cantidad);
        double precioUnitario = devolverValor(combo, cantidad);
        double iva = devolverIva(combo, cantidad);

        if (cantidad > cantProductoStock) {
            JOptionPane.showMessageDialog(null, "La cantidad supera el Stock");
            return;
        }

        double subtotal = precioUnitario * cantidad;
        double totalAPagar = subtotal + iva;

        subtotal = Math.round(subtotal * 100) / 100.0;
        iva = Math.round(iva * 100) / 100.0;
        totalAPagar = Math.round(totalAPagar * 100) / 100.0;

        detallePedido producto = new detallePedido(auxIdDetalle,
                1,
                idProducto,
                productoNombre,
                cantidad,
                precioUnitario,
                subtotal,
                iva,
                totalAPagar,
                0
        );

        listaProductos.add(producto);
        JOptionPane.showMessageDialog(null, "Producto Agregado");
        auxIdDetalle++;
        calcularTotal(listaProductos, txtSubtotal, txtIva, txtTotal);
        
    }

    public static void calcularVuelto(String efectivoText, String totalText, JTextField txtVuelto) {
        if (efectivoText.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingresa la cantidad de efectivo");
            return;
        }

        boolean validacion = validarDouble(efectivoText);
        if (!validacion) {
            JOptionPane.showMessageDialog(null, "Ingrese números");
            return;
        }

        double efectivo = Double.parseDouble(efectivoText.trim());
        double total = Double.parseDouble(totalText.trim());

        if (efectivo < total) {
            JOptionPane.showMessageDialog(null, "El efectivo no es suficiente");
        } else {
            double cambio = efectivo - total;
            double cambioRedondeado = Math.round(cambio * 100d) / 100d;
            txtVuelto.setText(String.valueOf(cambioRedondeado));
        }
    }
    public List<Map<String, Object>> CargarHistorial(String fechaInicio, String fechaFin){
         
       return dao.CargarHistorial(fechaInicio, fechaFin);
    }
}
