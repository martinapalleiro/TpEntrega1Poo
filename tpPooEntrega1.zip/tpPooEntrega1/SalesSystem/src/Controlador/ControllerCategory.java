
package Controlador;

import java.util.List;
import modelo.DAOSS.DaoCategorias;
import modelo.Entitys.Categoria;


public class ControllerCategory {
    

    public boolean registrarCategoria(String descripcion) {
        if (!DaoCategorias.existeCategoria(descripcion)) {
            Categoria nuevaCategoria = new Categoria();
            nuevaCategoria.setDescripcion(descripcion);
            nuevaCategoria.setEstado(1);

            return DaoCategorias.guardarCategoria(nuevaCategoria);
        }
        return false;
    }

    public boolean existeCateg(String categoria) {
        return DaoCategorias.existeCategoria(categoria);
    }


    public List<Categoria> cargarCategorias() {
        return DaoCategorias.obtenerTodos();
    }

    public Categoria obtenerCateg(int id) {
        return DaoCategorias.obtenerCategoriaPorId(id);
    }

    public static boolean actualizar(Categoria categoria, int idCategoria) {
        return DaoCategorias.actualizarCategoria(categoria, idCategoria);
    }

    public static boolean eliminar(int id) {
        return DaoCategorias.eliminarCategoria(id);
    }
}
