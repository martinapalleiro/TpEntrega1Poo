package Controlador;

import java.util.List;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import modelo.DAOSS.DaoUsuario;
import modelo.Entitys.Usuario;

public class ControllerUsuario {

    public static boolean iniciarSesion(Usuario objeto) {
        return DaoUsuario.iniciarSesionDao(objeto);
    }

    public boolean registrarUsuario(String puesto, String nombre, String apellido, long dni, String celular, String domicilio, String usuario, String contra) {
        if (!existeUsuario(usuario)) {
            Usuario nuevoUsuario = new Usuario();
            nuevoUsuario.setPuesto(puesto);
            nuevoUsuario.setNombre(nombre);
            nuevoUsuario.setApellido(apellido);
            nuevoUsuario.setDni(dni);
            nuevoUsuario.setCelular(celular);
            nuevoUsuario.setDomicilio(domicilio);
            nuevoUsuario.setUsuario(usuario);
            nuevoUsuario.setContra(contra);
            nuevoUsuario.setEstado(1);

            return DaoUsuario.guardarUsuario(nuevoUsuario);
        }
        return false;
    }

    public boolean existeUsuario(String usuario) {
        return DaoUsuario.existeUsuario(usuario);
    }

    public static void passwordVisibility(boolean isVisible, JPasswordField txt_contra, JTextField txt_contraVisible) {
        if (isVisible) {
            String pass = new String(txt_contra.getPassword());
            txt_contraVisible.setText(pass);
            txt_contra.setVisible(false);
            txt_contraVisible.setVisible(true);
        } else {
            String passwordIngresada = txt_contraVisible.getText().trim();
            txt_contra.setText(passwordIngresada);
            txt_contra.setVisible(true);
            txt_contraVisible.setVisible(false);
        }
    }

    public List<Usuario> cargarUsuarios() {
        return DaoUsuario.obtenerTodos();
    }

    public Usuario obtenerUsuario(int id) {
        return DaoUsuario.obtenerUsuarioPorId(id);
    }

    public static boolean actualizar(Usuario usuario, int idUsuario) {
        return DaoUsuario.actualizarUsuario(usuario, idUsuario);
    }

    public static boolean eliminar(int id) {
        return DaoUsuario.eliminarUsuario(id);
    }
}
