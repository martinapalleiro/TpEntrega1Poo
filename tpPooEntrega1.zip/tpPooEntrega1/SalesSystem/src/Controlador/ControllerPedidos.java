package Controlador;

import modelo.Entitys.Pedido;

import java.util.ArrayList;


import java.util.List;
import modelo.DAOSS.DaoPedidos;

public class ControllerPedidos {

    public static List<String> cargarCliente() {
        return DaoPedidos.cargarClientes();

    }

    public static List<Object[]> cargarTablaVentas() {
        DaoPedidos daoVentas = new DaoPedidos();
        List<Pedido> ventas = daoVentas.cargarVentas();
        List<Object[]> datosVentas = new ArrayList<>();

        for (Pedido venta : ventas) {
            Object[] fila = new Object[5];
            fila[0] = venta.getIdCliente();
            fila[1] = venta.getCliente();
            fila[2] = venta.getTotal();
            fila[3] = venta.getFechaVenta();
            fila[4] = (venta.getEstado() == 1) ? "Entregado" : "Para armar";
            datosVentas.add(fila);
        }

        return datosVentas;
    }


   public static Object[] enviarDatosVentaSeleccionada(int id) {
    System.out.println("ID solicitado: " + id);
    Pedido venta = DaoPedidos.enviarDatosVenta(id);

    if (venta == null) {
        System.out.println("No se encontró la venta para el ID: " + id);
        return null; 
    }

    String estado;
    switch (venta.getEstado()) {
        case 1:
            estado = "Entregado";
            break;
        default:
            estado = "Para armar";
            break;
       
    }

    System.out.println("Cliente: " + venta.getCliente() + ", Estado: " + estado);
    
    return new Object[]{venta.getTotal(), venta.getFechaVenta(), venta.getCliente(), estado};
}


    public boolean actualizarPedido(String cliente, String estado, int idVenta) {
        return DaoPedidos.actualizarPedido(cliente, estado, idVenta);
    }
}
