package Controlador;

import java.util.ArrayList;
import java.util.List;
import modelo.DAOSS.DaoProductos;
import modelo.Entitys.Productos;

public class ControllerProducto {

    DaoProductos daoProd = new DaoProductos();

    public boolean guardar(Productos producto) {

        boolean respuesta = false;
        if (daoProd.guardar(producto)) {
            respuesta = true;
        }

        return respuesta;
    }

    public int traerIdCateg(String nombreCat) {

        return daoProd.idCategoria(nombreCat);
    }

    public String traerNombreCateg(int id) {
        return daoProd.nombreCategoria(id);
    }

    public List<String> cargarListCategorias() {
        return daoProd.cargarCategorias();
    }

    public boolean existeProducto(String nombre) {
        boolean respuesta = false;
        if (daoProd.existeProducto(nombre)) {
            respuesta = true;
        }
        return respuesta;
    }

    public ArrayList<Productos> CargarTablaProductos() {

        return daoProd.CargarProductos();
    }

    public double calcularIva(double precio, double porcentajeIva) {
        if (porcentajeIva == 0) {
            return 0;
        } else if (porcentajeIva == 10 || porcentajeIva == 10.5 || porcentajeIva == 11) {
            return Math.round((precio * 10.5) / 100);
        } else if (porcentajeIva == 21) {
            return Math.round((precio * 21) / 100);
        } else {
            return Math.round((precio * 27) / 100);
        }

    }

    public Productos getProdSeleccionado(int idProducto) {

        return daoProd.EnviarDatosProd(idProducto);
    }

    public boolean actualizar(Productos objeto, int idProductos) {

        boolean respuesta = false;
        if (daoProd.actualizar(objeto, idProductos)) {
            respuesta = true;
        }
        return respuesta;
    }

    public boolean eliminar(int id) {
        return daoProd.eliminarProducto(id);
    }

    public List<String> cargarComboProds() {
        return daoProd.cargarComboProductos();
    }

    public int mostrarStock(String prod) {
        return daoProd.traerStock(prod);
    }

    public int traerId(String prod) {
        return daoProd.traerIdProd(prod);
    }

    public boolean ActualizarStock(Productos producto, int idProducto) {

        boolean respuesta = false;
        if (daoProd.ActualizarStock(producto, idProducto)) {
            respuesta = true;
        }
        return respuesta;
    }

}
