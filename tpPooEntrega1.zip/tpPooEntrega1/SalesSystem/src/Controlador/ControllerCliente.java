
package Controlador;

import modelo.Entitys.Cliente;
import java.util.ArrayList;
import modelo.DAOSS.DAOCliente;

public class ControllerCliente {
    
    DAOCliente daoCliente = new DAOCliente();
    
    
    public boolean guardar(Cliente objeto){
        
        boolean respuesta = false;
        if(daoCliente.guardar(objeto)){
            respuesta = true;
        }
        
        return respuesta;
    }
    
    public boolean existeCliente(String dni){
        boolean respuesta = false;
        if(daoCliente.existeCliente(dni)){
            respuesta = true;
        }
        return respuesta;
    }
     public ArrayList<Cliente> CargarClientes() {
        return daoCliente.CargarClientes();

    }

    public Cliente getClienteSeleccionado(int idCliente) {

        return daoCliente.EnviarDatosCliente(idCliente);
    }

    public boolean actualizar(Cliente objeto, int idCliente) {

        boolean respuesta = false;
        if (daoCliente.actualizar(objeto, idCliente)) {
            respuesta = true;
        }
        return respuesta;
    }

    public boolean eliminar(int idCliente) {
        boolean respuesta = false;
        if (daoCliente.eliminar(idCliente)) {
            respuesta = true;
        }
        return respuesta;
    }
}
