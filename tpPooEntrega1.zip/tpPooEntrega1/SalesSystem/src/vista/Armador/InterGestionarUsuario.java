package vista.Armador;

import Controlador.ControllerUsuario;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Entitys.Usuario;
import java.util.List;

public class InterGestionarUsuario extends javax.swing.JInternalFrame {

    private int idUsuario;

    public InterGestionarUsuario() {
        initComponents();
        this.setSize(new Dimension(900, 500));
        this.setTitle("Gestionar Usuarios");
        this.cargarTablaUsuarios();

        ImageIcon wallPaper = new ImageIcon("src/img/fondo3.jpg");
        Icon icono = new ImageIcon(wallPaper.getImage().getScaledInstance(900, 500, WIDTH));
        jLabel_wallPaper.setIcon(icono);

        this.repaint();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSplitPane1 = new javax.swing.JSplitPane();
        jPanel2 = new javax.swing.JPanel();
        jButton_actualizar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable_usuarios = new javax.swing.JTable();
        jLabel12 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txt_nombre = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txt_dni = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txt_apellido = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txt_usuario = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txt_domicilio = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txt_celular = new javax.swing.JTextField();
        jComboBox_puesto = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        txt_contra = new javax.swing.JTextField();
        jLabel_wallPaper = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel2.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton_actualizar.setBackground(new java.awt.Color(204, 255, 204));
        jButton_actualizar.setForeground(new java.awt.Color(0, 0, 0));
        jButton_actualizar.setText("Actualizar");
        jButton_actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_actualizarActionPerformed(evt);
            }
        });
        jPanel2.add(jButton_actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 100, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 60, 140, 250));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable_usuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable_usuarios);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 11, 650, 230));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 680, 250));

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Gestionar Usuarios");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 0, 170, 50));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel2.setText("Nombre:");
        jLabel2.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 80, 20));

        txt_nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nombreActionPerformed(evt);
            }
        });
        jPanel3.add(txt_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, 170, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("DNI:");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, -1, -1));

        txt_dni.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_dniActionPerformed(evt);
            }
        });
        jPanel3.add(txt_dni, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 20, 180, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Apellido:");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Celular:");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 60, -1, -1));
        jPanel3.add(txt_apellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 60, 170, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Contraseña:");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 100, -1, -1));
        jPanel3.add(txt_usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 100, 180, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Domicilio:");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 20, -1, -1));

        txt_domicilio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_domicilioActionPerformed(evt);
            }
        });
        jPanel3.add(txt_domicilio, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 20, 180, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("Puesto:");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 60, -1, -1));
        jPanel3.add(txt_celular, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 60, 180, -1));

        jComboBox_puesto.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_puesto.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_puesto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione Puesto", "Cajero", "Armador de pedidos", "Gerente" }));
        jComboBox_puesto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_puestoActionPerformed(evt);
            }
        });
        jPanel3.add(jComboBox_puesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 60, 190, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Usuario:");
        jPanel3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 100, -1, -1));
        jPanel3.add(txt_contra, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 100, 180, -1));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, 840, 130));
        getContentPane().add(jLabel_wallPaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 890, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_nombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nombreActionPerformed

    private void txt_dniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_dniActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_dniActionPerformed

    private void txt_domicilioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_domicilioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_domicilioActionPerformed

    private void jComboBox_puestoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_puestoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox_puestoActionPerformed

    private void jButton_actualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_actualizarActionPerformed
        Usuario usuario = new Usuario();
        ControllerUsuario controladorUsuario = new ControllerUsuario();

        if (idUsuario == 0) {
            JOptionPane.showMessageDialog(null, "Seleccione un usuario");
        } else {
            if (txt_nombre.getText().isEmpty() || txt_apellido.getText().isEmpty() || txt_dni.getText().isEmpty()
                    || txt_celular.getText().isEmpty() || txt_domicilio.getText().isEmpty() || txt_usuario.getText().isEmpty() || txt_contra.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Completa todos los campos");
            } else {
                usuario.setId(idUsuario);  // Asegúrate de establecer el ID correcto
                usuario.setPuesto((String) jComboBox_puesto.getSelectedItem());
                usuario.setNombre(txt_nombre.getText().trim());
                usuario.setApellido(txt_apellido.getText().trim());
                String dni = txt_dni.getText().trim();
                if (dni.matches("\\d+")) {
                    long dniLong = Long.parseLong(dni);
                    usuario.setDni(dniLong);
                } else {
                    JOptionPane.showMessageDialog(null, "El texto no es un número válido:" + dni);
                    return; // Salir del método si el DNI no es válido
                }
                usuario.setCelular(txt_celular.getText().trim());
                usuario.setDomicilio(txt_domicilio.getText().trim());
                usuario.setUsuario(txt_usuario.getText().trim());
                usuario.setContra(txt_contra.getText().trim());
                usuario.setEstado(1);

                // Llama al controlador para actualizar el usuario
                if (controladorUsuario.actualizar(usuario, idUsuario)) {
                    JOptionPane.showMessageDialog(null, "Actualización exitosa.");
                    this.limpiar();
                    this.cargarTablaUsuarios();
                    idUsuario = 0; // Resetear el ID del usuario
                } else {
                    JOptionPane.showMessageDialog(null, "Error al actualizar usuario.");
                }
            }
        }
    }//GEN-LAST:event_jButton_actualizarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_actualizar;
    private javax.swing.JComboBox<String> jComboBox_puesto;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel_wallPaper;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    public static javax.swing.JScrollPane jScrollPane2;
    public static javax.swing.JSplitPane jSplitPane1;
    public static javax.swing.JTable jTable_usuarios;
    private javax.swing.JTextField txt_apellido;
    private javax.swing.JTextField txt_celular;
    private javax.swing.JTextField txt_contra;
    private javax.swing.JTextField txt_dni;
    private javax.swing.JTextField txt_domicilio;
    private javax.swing.JTextField txt_nombre;
    private javax.swing.JTextField txt_usuario;
    // End of variables declaration//GEN-END:variables

    private void limpiar() {
        txt_nombre.setText("");
        txt_apellido.setText("");
        txt_dni.setText("");
        txt_celular.setText("");
        txt_domicilio.setText("");
        txt_usuario.setText("");
        txt_contra.setText("");

    }

    private void cargarTablaUsuarios() { //cambiar ahora
        ControllerUsuario controller = new ControllerUsuario();
        List<Usuario> usuarios = controller.cargarUsuarios();

        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Puesto");
        model.addColumn("Nombre");
        model.addColumn("Apellido");
        model.addColumn("DNI");
        model.addColumn("Celular");
        model.addColumn("Domicilio");
        model.addColumn("Usuario");

        for (Usuario usuario : usuarios) {
            Object[] fila = new Object[8];
            fila[0] = usuario.getId();
            fila[1] = usuario.getPuesto();
            fila[2] = usuario.getNombre();
            fila[3] = usuario.getApellido();
            fila[4] = usuario.getDni();
            fila[5] = usuario.getCelular();
            fila[6] = usuario.getDomicilio();
            fila[7] = usuario.getUsuario();
            model.addRow(fila);
        }

        InterGestionarUsuario.jTable_usuarios.setModel(model);
        jTable_usuarios.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int fila_point = jTable_usuarios.rowAtPoint(e.getPoint());
                if (fila_point > -1) {
                    idUsuario = (int) model.getValueAt(fila_point, 0);
                    enviarDatosUsuarioSeleccionado(idUsuario);
                }
            }
        });
    }

    private void enviarDatosUsuarioSeleccionado(int id) {
        ControllerUsuario controller = new ControllerUsuario();
        Usuario usuario = controller.obtenerUsuario(id);

        if (usuario != null) {
            jComboBox_puesto.setSelectedItem(usuario.getPuesto());
            txt_nombre.setText(usuario.getNombre());
            txt_apellido.setText(usuario.getApellido());
            txt_dni.setText(String.valueOf(usuario.getDni()));
            txt_celular.setText(usuario.getCelular());
            txt_domicilio.setText(usuario.getDomicilio());
            txt_usuario.setText(usuario.getUsuario());
        }
    }

}
