package vista.Armador;

import Controlador.ControllerCategory;
import java.awt.Dimension;
import javax.swing.JOptionPane;


public class InterCategoria extends javax.swing.JInternalFrame {

    
    public InterCategoria() {
        initComponents();
        this.setSize(new Dimension(400, 200));
        this.setTitle("Nueva Categoria");
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txt_descripcion = new javax.swing.JTextField();
        jButton_Guardar = new javax.swing.JButton();
        jLabel_wallPaper = new javax.swing.JLabel();

        jLabel1.setText("jLabel1");

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nueva categoria");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 0, 140, 50));

        txt_descripcion.setBackground(new java.awt.Color(255, 255, 255));
        txt_descripcion.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(txt_descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 170, -1));

        jButton_Guardar.setBackground(new java.awt.Color(255, 255, 255));
        jButton_Guardar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton_Guardar.setForeground(new java.awt.Color(0, 0, 0));
        jButton_Guardar.setText("Guardar");
        jButton_Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_GuardarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 90, -1, -1));

        jLabel_wallPaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondo3.jpg"))); // NOI18N
        getContentPane().add(jLabel_wallPaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 390, 170));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_GuardarActionPerformed
        if (txt_descripcion.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Completa el dato");
        } else {
          
            String descripcion = txt_descripcion.getText().trim();

            
                ControllerCategory controladorCate = new ControllerCategory();
                if (controladorCate.registrarCategoria(descripcion)) {
                    JOptionPane.showMessageDialog(null, "Categoria registrada");
                    this.Limpiar();
                } else {
                    JOptionPane.showMessageDialog(null, "La categoria ya está registrada o hubo un error en el registro.");
                }
            
        }

    }//GEN-LAST:event_jButton_GuardarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_Guardar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel_wallPaper;
    private javax.swing.JTextField txt_descripcion;
    // End of variables declaration//GEN-END:variables

     private void Limpiar() {
         txt_descripcion.setText("");
        

    }
}
