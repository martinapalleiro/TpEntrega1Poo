package vista.Gerente;

import Controlador.ControllerPedidos;
import Controlador.ControllerPedidosDetalles;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import javax.swing.table.DefaultTableModel;


/**
 *
 * @author Martina
 */
public class InterGestionarVentas extends javax.swing.JInternalFrame {

    public int idCliente = 0;
    public int idVenta;


    public InterGestionarVentas() {
        initComponents();
        this.setSize(new Dimension(900, 500));
        this.setTitle("Gestionar Ventas");

        this.cargarClientes();
        this.cargarEstados();

        List<Object[]> datosVentas = ControllerPedidos.cargarTablaVentas();
        this.actualizarTablaVentas(datosVentas);
       

        ImageIcon wallPaper = new ImageIcon("src/img/fondo3.jpg");
        Icon icono = new ImageIcon(wallPaper.getImage().getScaledInstance(900, 500, WIDTH));
        jLabel_wallPaper.setIcon(icono);
        txt_total.setEnabled(false);
        txt_fecha.setEnabled(false);
        this.repaint();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSplitPane1 = new javax.swing.JSplitPane();
        jPanel2 = new javax.swing.JPanel();
        jButton_actualizar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_ventas = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txt_total = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txt_fecha = new javax.swing.JTextField();
        jComboBox_cliente = new javax.swing.JComboBox<>();
        jComboBox_estado = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel_wallPaper = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel2.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton_actualizar.setBackground(new java.awt.Color(204, 255, 204));
        jButton_actualizar.setForeground(new java.awt.Color(0, 0, 0));
        jButton_actualizar.setText("Actualizar");
        jButton_actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_actualizarActionPerformed(evt);
            }
        });
        jPanel2.add(jButton_actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 100, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 60, 140, 250));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable_ventas.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTable_ventas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable_ventas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_ventasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable_ventas);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 640, 230));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 680, 250));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel2.setText("Total:");
        jLabel2.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 80, 20));

        txt_total.setBackground(new java.awt.Color(204, 204, 204));
        txt_total.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_totalActionPerformed(evt);
            }
        });
        jPanel3.add(txt_total, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, 170, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Cliente:");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 20, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Fecha:");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Estado:");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 60, -1, -1));

        txt_fecha.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.add(txt_fecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 60, 170, -1));

        jComboBox_cliente.setBackground(new java.awt.Color(204, 204, 204));
        jComboBox_cliente.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_cliente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar Cliente:", "Item 2", "Item 3", "Item 4" }));
        jComboBox_cliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_clienteActionPerformed(evt);
            }
        });
        jPanel3.add(jComboBox_cliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 20, 180, -1));

        jComboBox_estado.setBackground(new java.awt.Color(204, 204, 204));
        jComboBox_estado.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione un estado:", "Para armar", "Entregado" }));
        jComboBox_estado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_estadoActionPerformed(evt);
            }
        });
        jPanel3.add(jComboBox_estado, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 60, 180, -1));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, 840, 130));

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Cantidad:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 130, 140, 50));

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Gestionar Ventas");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 0, 170, 50));
        getContentPane().add(jLabel_wallPaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 890, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_totalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_totalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_totalActionPerformed

    private void jComboBox_clienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_clienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox_clienteActionPerformed

    private void jComboBox_estadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_estadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox_estadoActionPerformed

    private void jButton_actualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_actualizarActionPerformed
        String cliente = jComboBox_cliente.getSelectedItem().toString().trim();
        String estado = jComboBox_estado.getSelectedItem().toString().trim();

        if (!cliente.equalsIgnoreCase("Seleccionar Cliente:")) {

            ControllerPedidos controladorPedido = new ControllerPedidos();

           
            System.out.println("id n" + idVenta);
            if (controladorPedido.actualizarPedido(cliente, estado, idVenta)) {
                JOptionPane.showMessageDialog(null, "Actualizado correctamente");
                List<Object[]> datosVentas = ControllerPedidos.cargarTablaVentas();
                actualizarTablaVentas(datosVentas);
                this.limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al actualizar");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione una venta para actualizar los datos");
        }


    }//GEN-LAST:event_jButton_actualizarActionPerformed

    private void jTable_ventasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_ventasMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable_ventasMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_actualizar;
    public static javax.swing.JComboBox<String> jComboBox_cliente;
    public static javax.swing.JComboBox<String> jComboBox_estado;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel_wallPaper;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    public static javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSplitPane jSplitPane1;
    public static javax.swing.JTable jTable_ventas;
    public static javax.swing.JTextField txt_fecha;
    public static javax.swing.JTextField txt_total;
    // End of variables declaration//GEN-END:variables

    private void limpiar() {
        txt_total.setText("");
        txt_fecha.setText("");
        jComboBox_cliente.setSelectedItem("Seleccione cliente:");
        jComboBox_estado.setSelectedItem("Para armar");
        idCliente = 0;
    }

    public void actualizarTablaVentas(List<Object[]> datosVentas) {

        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Cliente");
        model.addColumn("Total");
        model.addColumn("Fecha");
        model.addColumn("Estado");

        for (Object[] fila : datosVentas) {
            model.addRow(fila);
        }

        InterGestionarVentas.jTable_ventas.setModel(model);
        InterGestionarVentas.jScrollPane1.setViewportView(InterGestionarVentas.jTable_ventas);

        InterGestionarVentas.jTable_ventas.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int fila_point = InterGestionarVentas.jTable_ventas.rowAtPoint(e.getPoint());
                if (fila_point >= 0) {
                     idVenta = (int) model.getValueAt(fila_point, 0);
                    System.out.println("ID de venta seleccionada: " + idVenta);
                    System.out.println("Llamando a enviarDatosVentaSeleccionada con ID: " + idVenta);

                    Object[] datosVenta = ControllerPedidos.enviarDatosVentaSeleccionada(idVenta);
                    if (datosVenta != null) {
                        this.actualizarVista(idVenta);
                    } else {
                        System.out.println("No se encontraron datos de venta.");
                    }
                }
            }

            private void actualizarVista(int id) {
                Object[] datosVenta = ControllerPedidos.enviarDatosVentaSeleccionada(id);

                if (datosVenta != null) {
                    InterGestionarVentas.txt_total.setText(String.valueOf(datosVenta[0]));
                    InterGestionarVentas.txt_fecha.setText((String) datosVenta[1]);

                    cargarEstados();
                   
                    String clienteSeleccionado = (String) datosVenta[2];
                    String estadoSeleccionado = (String) datosVenta[3];

                    
                    try {
                        InterGestionarVentas.jComboBox_cliente.setSelectedItem(clienteSeleccionado);
                        InterGestionarVentas.jComboBox_estado.setSelectedItem(estadoSeleccionado);
                    } catch (Exception e) {
                        System.out.println("Error al seleccionar cliente o estado: " + e.getMessage());
                    }
                } else {
                    System.out.println("No se encontró la venta para el ID: " + id);
                }
            }

        });
    }

    private void cargarClientes() {
        try {
            List<String> clientes = ControllerPedidosDetalles.cargarListaClientes(); 
            this.jComboBox_cliente.removeAllItems();
            this.jComboBox_cliente.addItem("Seleccione cliente");
            for (String cliente : clientes) {
                this.jComboBox_cliente.addItem(cliente); 
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar datos: " + e.getMessage());
        }
    }

    private void cargarEstados() {
        InterGestionarVentas.jComboBox_estado.removeAllItems();
       
        InterGestionarVentas.jComboBox_estado.addItem("Entregado");
        InterGestionarVentas.jComboBox_estado.addItem("Para armar");
    }

}
