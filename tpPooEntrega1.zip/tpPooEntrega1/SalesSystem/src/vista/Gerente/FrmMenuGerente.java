
package vista.Gerente;

import java.awt.Dimension;
import javax.swing.JDesktopPane;

public class FrmMenuGerente extends javax.swing.JFrame {

    public static JDesktopPane jDesktopPane_menu;
    
    public FrmMenuGerente() {
        initComponents();
        this.setSize(new Dimension(1200,700));
        this.setExtendedState(FrmMenuGerente.MAXIMIZED_BOTH);
        this.setLocationRelativeTo(null);
        this.setTitle("Sistema de Ventas");
        
        this.setLayout(null);
        jDesktopPane_menu=new JDesktopPane();
        
        int ancho=java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
        int alto=java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;
        FrmMenuGerente.jDesktopPane_menu.setBounds(0,0,ancho,(alto-110));
        this.add(jDesktopPane_menu);
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem_nuevoUsuario = new javax.swing.JMenuItem();
        jMenuItem_gestionarUsuarios = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem_nuevoProducto = new javax.swing.JMenuItem();
        jMenuItem_gestionarProductos = new javax.swing.JMenuItem();
        jMenuItem_actualizarStock = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem_nuevoCliente = new javax.swing.JMenuItem();
        jMenuItem_gestionarClientes = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        jMenuItem_nuevaCategoria = new javax.swing.JMenuItem();
        jMenuItem_gestionarCategorias = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        jMenuItem_nuevaVenta = new javax.swing.JMenuItem();
        jMenuItem_gestionarVentas = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        jMenuItem_verHistorial = new javax.swing.JMenuItem();
        jMenu8 = new javax.swing.JMenu();
        jMenuItem_cerrarSesion = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/usuario.png"))); // NOI18N
        jMenu1.setText("Usuario");
        jMenu1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jMenu1.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_nuevoUsuario.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_nuevoUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/nuevo-cliente.png"))); // NOI18N
        jMenuItem_nuevoUsuario.setText("Nuevo Usuario");
        jMenuItem_nuevoUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_nuevoUsuarioActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem_nuevoUsuario);

        jMenuItem_gestionarUsuarios.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_gestionarUsuarios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/configuraciones.png"))); // NOI18N
        jMenuItem_gestionarUsuarios.setText("Gestionar Usuarios");
        jMenuItem_gestionarUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_gestionarUsuariosActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem_gestionarUsuarios);

        jMenuBar1.add(jMenu1);

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/producto.png"))); // NOI18N
        jMenu2.setText("Productos");
        jMenu2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jMenu2.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_nuevoProducto.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_nuevoProducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/nuevo-producto.png"))); // NOI18N
        jMenuItem_nuevoProducto.setText("Nuevo Producto");
        jMenuItem_nuevoProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_nuevoProductoActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem_nuevoProducto);

        jMenuItem_gestionarProductos.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_gestionarProductos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/producto.png"))); // NOI18N
        jMenuItem_gestionarProductos.setText("Gestionar Productos");
        jMenuItem_gestionarProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_gestionarProductosActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem_gestionarProductos);

        jMenuItem_actualizarStock.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_actualizarStock.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/nuevo.png"))); // NOI18N
        jMenuItem_actualizarStock.setText("Actualizar Stock");
        jMenuItem_actualizarStock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_actualizarStockActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem_actualizarStock);

        jMenuBar1.add(jMenu2);

        jMenu3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cliente.png"))); // NOI18N
        jMenu3.setText("Cliente");
        jMenu3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jMenu3.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_nuevoCliente.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_nuevoCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/nuevo-cliente.png"))); // NOI18N
        jMenuItem_nuevoCliente.setText("Nuevo Cliente");
        jMenuItem_nuevoCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_nuevoClienteActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem_nuevoCliente);

        jMenuItem_gestionarClientes.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_gestionarClientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cliente.png"))); // NOI18N
        jMenuItem_gestionarClientes.setText("Gestionar Clientes");
        jMenuItem_gestionarClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_gestionarClientesActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem_gestionarClientes);

        jMenuBar1.add(jMenu3);

        jMenu4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/categorias.png"))); // NOI18N
        jMenu4.setText("Categorias");
        jMenu4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jMenu4.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_nuevaCategoria.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_nuevaCategoria.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/nuevo.png"))); // NOI18N
        jMenuItem_nuevaCategoria.setText("Nueva Categoria");
        jMenuItem_nuevaCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_nuevaCategoriaActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem_nuevaCategoria);

        jMenuItem_gestionarCategorias.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_gestionarCategorias.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/categorias.png"))); // NOI18N
        jMenuItem_gestionarCategorias.setText("Gestionar categorias");
        jMenuItem_gestionarCategorias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_gestionarCategoriasActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem_gestionarCategorias);

        jMenuBar1.add(jMenu4);

        jMenu5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/carrito.png"))); // NOI18N
        jMenu5.setText("Facturar");
        jMenu5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jMenu5.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_nuevaVenta.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_nuevaVenta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/anadir.png"))); // NOI18N
        jMenuItem_nuevaVenta.setText("Nueva Venta");
        jMenuItem_nuevaVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_nuevaVentaActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem_nuevaVenta);

        jMenuItem_gestionarVentas.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_gestionarVentas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/configuraciones.png"))); // NOI18N
        jMenuItem_gestionarVentas.setText("Gestionar Ventas");
        jMenuItem_gestionarVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_gestionarVentasActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem_gestionarVentas);

        jMenuBar1.add(jMenu5);

        jMenu7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/historial1.png"))); // NOI18N
        jMenu7.setText("Historial");
        jMenu7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jMenu7.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_verHistorial.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_verHistorial.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/historial1.png"))); // NOI18N
        jMenuItem_verHistorial.setText("Ver Historial");
        jMenuItem_verHistorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_verHistorialActionPerformed(evt);
            }
        });
        jMenu7.add(jMenuItem_verHistorial);

        jMenuBar1.add(jMenu7);

        jMenu8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cerrar-sesion.png"))); // NOI18N
        jMenu8.setText("Cerrar Sesion");
        jMenu8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jMenu8.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_cerrarSesion.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_cerrarSesion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cerrar-sesion.png"))); // NOI18N
        jMenuItem_cerrarSesion.setText("Cerrar Sesion");
        jMenuItem_cerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_cerrarSesionActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem_cerrarSesion);

        jMenuBar1.add(jMenu8);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem_nuevoUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_nuevoUsuarioActionPerformed
        InterUsuario interUsuario=new InterUsuario();
        jDesktopPane_menu.add(interUsuario);
       interUsuario.setVisible(true);
    }//GEN-LAST:event_jMenuItem_nuevoUsuarioActionPerformed

    private void jMenuItem_nuevoProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_nuevoProductoActionPerformed
        InterProducto interProducto=new InterProducto();
        jDesktopPane_menu.add(interProducto);
       interProducto.setVisible(true);
    }//GEN-LAST:event_jMenuItem_nuevoProductoActionPerformed

    private void jMenuItem_gestionarProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_gestionarProductosActionPerformed
        InterGestionarProductos interGestProducto=new InterGestionarProductos();
        jDesktopPane_menu.add(interGestProducto);
       interGestProducto.setVisible(true);
    }//GEN-LAST:event_jMenuItem_gestionarProductosActionPerformed

    private void jMenuItem_actualizarStockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_actualizarStockActionPerformed
        InterActualizarStock interActualizarStock=new InterActualizarStock();
        jDesktopPane_menu.add(interActualizarStock);
       interActualizarStock.setVisible(true);
    }//GEN-LAST:event_jMenuItem_actualizarStockActionPerformed

    private void jMenuItem_nuevaVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_nuevaVentaActionPerformed
        InterFacturacion interFacturacion=new InterFacturacion();
        jDesktopPane_menu.add(interFacturacion);
       interFacturacion.setVisible(true);
    }//GEN-LAST:event_jMenuItem_nuevaVentaActionPerformed

    private void jMenuItem_nuevaCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_nuevaCategoriaActionPerformed
       InterCategoria interCategoria = new InterCategoria();
       jDesktopPane_menu.add(interCategoria);
       interCategoria.setVisible(true);
    }//GEN-LAST:event_jMenuItem_nuevaCategoriaActionPerformed

    private void jMenuItem_gestionarCategoriasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_gestionarCategoriasActionPerformed
        InterGestionarCategorias interGestCategoria=new InterGestionarCategorias();
        jDesktopPane_menu.add(interGestCategoria);
       interGestCategoria.setVisible(true);
    }//GEN-LAST:event_jMenuItem_gestionarCategoriasActionPerformed

    private void jMenuItem_nuevoClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_nuevoClienteActionPerformed
        InterCliente interCliente=new InterCliente();
        jDesktopPane_menu.add(interCliente);
       interCliente.setVisible(true);
    }//GEN-LAST:event_jMenuItem_nuevoClienteActionPerformed

    private void jMenuItem_gestionarClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_gestionarClientesActionPerformed
       InterGestionarClientes interGestCliente=new InterGestionarClientes();
        jDesktopPane_menu.add(interGestCliente);
       interGestCliente.setVisible(true);
    }//GEN-LAST:event_jMenuItem_gestionarClientesActionPerformed

    private void jMenuItem_gestionarUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_gestionarUsuariosActionPerformed
       InterGestionarUsuario interGestUsuario=new InterGestionarUsuario();
        jDesktopPane_menu.add(interGestUsuario);
       interGestUsuario.setVisible(true);
    }//GEN-LAST:event_jMenuItem_gestionarUsuariosActionPerformed

    private void jMenuItem_gestionarVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_gestionarVentasActionPerformed
        InterGestionarVentas interGestVentas=new InterGestionarVentas();
        jDesktopPane_menu.add(interGestVentas);
        interGestVentas.setVisible(true);
    }//GEN-LAST:event_jMenuItem_gestionarVentasActionPerformed

    private void jMenuItem_cerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_cerrarSesionActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jMenuItem_cerrarSesionActionPerformed

    private void jMenuItem_verHistorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_verHistorialActionPerformed
        InterHistorial interHistorial = new InterHistorial();
        jDesktopPane_menu.add(interHistorial);
        interHistorial.setVisible(true);
    }//GEN-LAST:event_jMenuItem_verHistorialActionPerformed
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmMenuGerente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmMenuGerente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmMenuGerente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmMenuGerente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmMenuGerente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem_actualizarStock;
    private javax.swing.JMenuItem jMenuItem_cerrarSesion;
    private javax.swing.JMenuItem jMenuItem_gestionarCategorias;
    private javax.swing.JMenuItem jMenuItem_gestionarClientes;
    private javax.swing.JMenuItem jMenuItem_gestionarProductos;
    private javax.swing.JMenuItem jMenuItem_gestionarUsuarios;
    private javax.swing.JMenuItem jMenuItem_gestionarVentas;
    private javax.swing.JMenuItem jMenuItem_nuevaCategoria;
    private javax.swing.JMenuItem jMenuItem_nuevaVenta;
    private javax.swing.JMenuItem jMenuItem_nuevoCliente;
    private javax.swing.JMenuItem jMenuItem_nuevoProducto;
    private javax.swing.JMenuItem jMenuItem_nuevoUsuario;
    private javax.swing.JMenuItem jMenuItem_verHistorial;
    // End of variables declaration//GEN-END:variables

}
