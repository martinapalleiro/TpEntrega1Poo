package vista.Gerente;

import Controlador.ControllerPedidosDetalles;
import java.awt.Dimension;
import static java.awt.image.ImageObserver.WIDTH;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Entitys.Cliente;


import modelo.Entitys.detallePedido;

/**
 *
 * @author Martina
 */
public class InterFacturacion extends javax.swing.JInternalFrame {

    private DefaultTableModel modeloDatosProductos = new DefaultTableModel();
    ArrayList<detallePedido> listaProductos = new ArrayList<>();

    public InterFacturacion() {
        initComponents();
        this.setSize(new Dimension(800, 600));
        this.setTitle("Nueva venta");

        ImageIcon wallPaper = new ImageIcon("src/img/fondo3.jpg");
        Icon icono = new ImageIcon(wallPaper.getImage().getScaledInstance(800, 600, WIDTH));
        jLabel_wallPaper.setIcon(icono);
        
        this.cargarProductos();
        this.cargarClientes();

        ControllerPedidosDetalles.cargarListaProductos();
        modeloDatosProductos = ControllerPedidosDetalles.inicializarTablaProductos();
        txt_efectivo.setEnabled(true);
        jButton_calcularVuelto.setEnabled(true);
        txt_subtotal.setText("0.0");
        txt_iva.setText("0.0");
        txt_total.setText("0.0");
        txt_iva.setEditable(false);
        txt_total.setEditable(false);
        txt_subtotal.setEditable(false);
        txt_vuelto.setEditable(false);
        jTable_productos.setModel(modeloDatosProductos);
        this.repaint();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jRadioButton1 = new javax.swing.JRadioButton();
        jComboBox_producto = new javax.swing.JComboBox<>();
        jComboBox_cliente = new javax.swing.JComboBox<>();
        txt_clienteABuscar = new javax.swing.JTextField();
        txt_cantidad = new javax.swing.JTextField();
        jButton_buscarCliente = new javax.swing.JButton();
        jButton_añadirProducto = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_productos = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txt_subtotal = new javax.swing.JTextField();
        txt_iva = new javax.swing.JTextField();
        txt_total = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txt_efectivo = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txt_vuelto = new javax.swing.JTextField();
        jButton_calcularVuelto = new javax.swing.JButton();
        jButton_registrarVenta = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel_wallPaper = new javax.swing.JLabel();

        jRadioButton1.setText("jRadioButton1");

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jComboBox_producto.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_producto.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_producto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar producto:", "Item 2", "Item 3", "Item 4" }));
        jComboBox_producto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_productoActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox_producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, 180, -1));

        jComboBox_cliente.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_cliente.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_cliente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar Cliente:", "Item 2", "Item 3", "Item 4" }));
        jComboBox_cliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_clienteActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox_cliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, 180, -1));

        txt_clienteABuscar.setBackground(new java.awt.Color(255, 255, 255));
        txt_clienteABuscar.setForeground(new java.awt.Color(0, 0, 0));
        txt_clienteABuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_clienteABuscarActionPerformed(evt);
            }
        });
        getContentPane().add(txt_clienteABuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 80, 160, -1));

        txt_cantidad.setBackground(new java.awt.Color(255, 255, 255));
        txt_cantidad.setForeground(new java.awt.Color(0, 0, 0));
        txt_cantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_cantidadActionPerformed(evt);
            }
        });
        getContentPane().add(txt_cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 140, 100, -1));

        jButton_buscarCliente.setBackground(new java.awt.Color(255, 255, 204));
        jButton_buscarCliente.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton_buscarCliente.setForeground(new java.awt.Color(0, 0, 0));
        jButton_buscarCliente.setText("Buscar");
        jButton_buscarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_buscarClienteActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_buscarCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 80, -1, -1));

        jButton_añadirProducto.setBackground(new java.awt.Color(255, 255, 204));
        jButton_añadirProducto.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton_añadirProducto.setForeground(new java.awt.Color(0, 0, 0));
        jButton_añadirProducto.setText("Añadir producto");
        jButton_añadirProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_añadirProductoActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_añadirProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 140, 130, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jTable_productos.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTable_productos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable_productos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_productosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable_productos);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 746, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 750, 210));
        jPanel1.getAccessibleContext().setAccessibleDescription("");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Subtotal:");

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("IVA:");

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Tolal a Pagar:");

        txt_subtotal.setBackground(new java.awt.Color(204, 204, 204));
        txt_subtotal.setForeground(new java.awt.Color(0, 0, 0));
        txt_subtotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_subtotalActionPerformed(evt);
            }
        });

        txt_iva.setBackground(new java.awt.Color(204, 204, 204));
        txt_iva.setForeground(new java.awt.Color(0, 0, 0));
        txt_iva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_ivaActionPerformed(evt);
            }
        });

        txt_total.setBackground(new java.awt.Color(204, 204, 204));
        txt_total.setForeground(new java.awt.Color(0, 0, 0));
        txt_total.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_totalActionPerformed(evt);
            }
        });

        jLabel13.setBackground(new java.awt.Color(255, 255, 255));
        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 0));
        jLabel13.setText("efectivo:");

        txt_efectivo.setBackground(new java.awt.Color(204, 204, 204));
        txt_efectivo.setForeground(new java.awt.Color(0, 0, 0));
        txt_efectivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_efectivoActionPerformed(evt);
            }
        });

        jLabel14.setBackground(new java.awt.Color(255, 255, 255));
        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 0, 0));
        jLabel14.setText("vuelto:");

        txt_vuelto.setBackground(new java.awt.Color(204, 204, 204));
        txt_vuelto.setForeground(new java.awt.Color(0, 0, 0));
        txt_vuelto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_vueltoActionPerformed(evt);
            }
        });

        jButton_calcularVuelto.setBackground(new java.awt.Color(255, 255, 204));
        jButton_calcularVuelto.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton_calcularVuelto.setForeground(new java.awt.Color(0, 0, 0));
        jButton_calcularVuelto.setText("Calcular vuelto");
        jButton_calcularVuelto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_calcularVueltoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(43, 43, 43)
                                .addComponent(txt_subtotal, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGap(18, 18, 18)
                                .addComponent(txt_total, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txt_iva, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14)
                            .addComponent(jLabel13))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_vuelto, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_efectivo, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addComponent(jButton_calcularVuelto, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(57, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txt_subtotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13)
                    .addComponent(txt_efectivo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel14)
                                    .addComponent(txt_vuelto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(20, 20, 20))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(18, 18, 18))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(txt_iva, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton_calcularVuelto)
                    .addComponent(txt_total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(52, 52, 52))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 410, 570, 150));

        jButton_registrarVenta.setBackground(new java.awt.Color(255, 255, 204));
        jButton_registrarVenta.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton_registrarVenta.setForeground(new java.awt.Color(0, 0, 0));
        jButton_registrarVenta.setText("Registrar venta");
        jButton_registrarVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_registrarVentaActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_registrarVenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 410, 170, 150));

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Cliente:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, 140, 50));

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Producto:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, 140, 50));

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Cantidad:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 130, 140, 50));

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Nueva venta");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 10, 140, 50));
        getContentPane().add(jLabel_wallPaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 790, 570));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox_productoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_productoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox_productoActionPerformed

    private void jComboBox_clienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_clienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox_clienteActionPerformed

    private void txt_clienteABuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_clienteABuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_clienteABuscarActionPerformed

    private void txt_cantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_cantidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_cantidadActionPerformed

    private void txt_subtotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_subtotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_subtotalActionPerformed

    private void txt_ivaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_ivaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_ivaActionPerformed

    private void txt_totalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_totalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_totalActionPerformed

    private void jButton_registrarVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_registrarVentaActionPerformed
        double total = Double.parseDouble(txt_total.getText());

        if (ControllerPedidosDetalles.registrarVenta(jComboBox_cliente, listaProductos, total)) {
            JOptionPane.showMessageDialog(null, "Pedido registrado");
            this.limpiarTodo();
            listaProductos.clear();
            ControllerPedidosDetalles.listarProductos(listaProductos, modeloDatosProductos);
        }
        
    }//GEN-LAST:event_jButton_registrarVentaActionPerformed

    private void txt_efectivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_efectivoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_efectivoActionPerformed

    private void txt_vueltoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_vueltoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_vueltoActionPerformed

    private void jButton_buscarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_buscarClienteActionPerformed
        String clienteABuscar = txt_clienteABuscar.getText().trim();
        ControllerPedidosDetalles controladorPedidosDetalles = new ControllerPedidosDetalles();
        Cliente cliente = controladorPedidosDetalles.buscarCliente(clienteABuscar);

        if (cliente != null) {
            jComboBox_cliente.setSelectedItem(cliente.getNombre() + " " + cliente.getApellido());
            txt_clienteABuscar.setText("");
        } else {
            jComboBox_cliente.setSelectedItem("Seleccione cliente");
            JOptionPane.showMessageDialog(null, "DNI del cliente incorrecto o no existente");
        }
    }//GEN-LAST:event_jButton_buscarClienteActionPerformed

    private void jButton_añadirProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_añadirProductoActionPerformed
        String combo = InterFacturacion.jComboBox_producto.getSelectedItem().toString();
        String cantidadText = txt_cantidad.getText();

        // Llama al método del controlador para agregar el producto
        ControllerPedidosDetalles.añadirProducto(combo, cantidadText, listaProductos, txt_subtotal, txt_iva, txt_total);
        this.cargarProductos();
        // Actualiza la tabla
        try {
            ControllerPedidosDetalles.listarProductos(listaProductos, modeloDatosProductos);
            jTable_productos.setModel(modeloDatosProductos);
            jTable_productos.updateUI();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar la tabla: " + e.getMessage());
            e.printStackTrace();
        }

    }//GEN-LAST:event_jButton_añadirProductoActionPerformed

    private void jButton_calcularVueltoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_calcularVueltoActionPerformed
        String efectivoText = txt_efectivo.getText();
        String totalText = txt_total.getText();

        ControllerPedidosDetalles.calcularVuelto(efectivoText, totalText, txt_vuelto);
    }//GEN-LAST:event_jButton_calcularVueltoActionPerformed

    private void jTable_productosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_productosMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable_productosMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_añadirProducto;
    private javax.swing.JButton jButton_buscarCliente;
    private javax.swing.JButton jButton_calcularVuelto;
    private javax.swing.JButton jButton_registrarVenta;
    public static javax.swing.JComboBox<String> jComboBox_cliente;
    public static javax.swing.JComboBox<String> jComboBox_producto;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel_wallPaper;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton jRadioButton1;
    public static javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTable_productos;
    public static transient javax.swing.JTextField txt_cantidad;
    public static javax.swing.JTextField txt_clienteABuscar;
    public static javax.swing.JTextField txt_efectivo;
    private javax.swing.JTextField txt_iva;
    private javax.swing.JTextField txt_subtotal;
    private javax.swing.JTextField txt_total;
    private javax.swing.JTextField txt_vuelto;
    // End of variables declaration//GEN-END:variables

    public void limpiar() {

        txt_subtotal.setText("0.0");
        txt_iva.setText("0.0");
        txt_total.setText("0.0");
        txt_efectivo.setText("0.0");
        txt_vuelto.setText("0.0");
        
        txt_cantidad.setText("");
        
    }
    public void limpiarTodo(){
        txt_subtotal.setText("0.0");
        txt_iva.setText("0.0");
        txt_total.setText("0.0");
        txt_efectivo.setText("0.0");
        txt_vuelto.setText("0.0");
        txt_cantidad.setText("");
        jComboBox_cliente.setSelectedItem("Seleccione cliente");
        jComboBox_producto.setSelectedItem("Seleccionar producto:");
        
    }

    public void cargarProductos() {
        try {
            // Cargar productos
            List<String> productos = ControllerPedidosDetalles.cargarListaProductos(); // Obtener la lista de productos
            jComboBox_producto.removeAllItems();
            jComboBox_producto.addItem("Seleccione producto:");
            for (String producto : productos) {
                jComboBox_producto.addItem(producto); // Cargar los productos en el JComboBox
            }

            modeloDatosProductos = ControllerPedidosDetalles.inicializarTablaProductos();
            jTable_productos.setModel(modeloDatosProductos);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar productos: " + e.getMessage());
        }

    }

    public void cargarClientes() {
        try {
            List<String> clientes = ControllerPedidosDetalles.cargarListaClientes(); // Obtener la lista de clientes.
            this.jComboBox_cliente.removeAllItems();
            this.jComboBox_cliente.addItem("Seleccione cliente");
            for (String cliente : clientes) {
                this.jComboBox_cliente.addItem(cliente); // Cargar los clientes en el JComboBox.
            }

            modeloDatosProductos = ControllerPedidosDetalles.inicializarTablaProductos();
            this.jTable_productos.setModel(modeloDatosProductos);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar datos: " + e.getMessage());
        }
    }
}
