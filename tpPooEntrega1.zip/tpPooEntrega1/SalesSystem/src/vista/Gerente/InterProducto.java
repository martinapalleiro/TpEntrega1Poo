package vista.Gerente;

import Controlador.ControllerProducto;
import java.awt.Dimension;
import java.awt.HeadlessException;
import java.util.List;
import javax.swing.JOptionPane;
import modelo.Entitys.Productos;

public class InterProducto extends javax.swing.JInternalFrame {

    int idCateg = 0;

    public InterProducto() {
        initComponents();

        this.setSize(new Dimension(400, 340));
        this.setTitle("Nuevo Producto");
        this.cargarCategorias();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txt_nombre = new javax.swing.JTextField();
        txt_stock = new javax.swing.JTextField();
        txt_descripcion = new javax.swing.JTextField();
        txt_precio = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jComboBox_iva = new javax.swing.JComboBox<>();
        jComboBox_categoria = new javax.swing.JComboBox<>();
        jButton_guardarProducto = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel_wallPaper = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nombre:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 80, -1, -1));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Stock:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, -1, 20));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Descripcion:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, -1, -1));

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Precio:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 170, -1, -1));

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Categoria:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 200, -1, -1));

        txt_nombre.setBackground(new java.awt.Color(255, 255, 255));
        txt_nombre.setForeground(new java.awt.Color(0, 0, 0));
        txt_nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nombreActionPerformed(evt);
            }
        });
        getContentPane().add(txt_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 70, 190, -1));

        txt_stock.setBackground(new java.awt.Color(255, 255, 255));
        txt_stock.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(txt_stock, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 130, 190, -1));

        txt_descripcion.setBackground(new java.awt.Color(255, 255, 255));
        txt_descripcion.setForeground(new java.awt.Color(0, 0, 0));
        txt_descripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_descripcionActionPerformed(evt);
            }
        });
        getContentPane().add(txt_descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 100, 190, -1));

        txt_precio.setBackground(new java.awt.Color(255, 255, 255));
        txt_precio.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(txt_precio, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 160, 190, -1));

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("IVA:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 50, -1));

        jComboBox_iva.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_iva.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_iva.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione iva:", "No grava iva", "10.5%", "21%", "27%" }));
        jComboBox_iva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_ivaActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox_iva, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 220, 190, -1));

        jComboBox_categoria.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_categoria.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_categoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione Categoria:", "item 2", "item 3", "item 4" }));
        jComboBox_categoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_categoriaActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox_categoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 190, 190, -1));

        jButton_guardarProducto.setBackground(new java.awt.Color(204, 204, 255));
        jButton_guardarProducto.setForeground(new java.awt.Color(0, 0, 0));
        jButton_guardarProducto.setText("Guardar");
        jButton_guardarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_guardarProductoActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_guardarProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 270, -1, -1));

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Nuevo Producto");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 0, 170, 50));

        jLabel_wallPaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondo3.jpg"))); // NOI18N
        getContentPane().add(jLabel_wallPaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 390, 320));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_nombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nombreActionPerformed

    private void txt_descripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_descripcionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_descripcionActionPerformed

    private void jComboBox_ivaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_ivaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox_ivaActionPerformed

    private void jComboBox_categoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_categoriaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox_categoriaActionPerformed

    private void jButton_guardarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_guardarProductoActionPerformed
        Productos prod = new Productos();
        ControllerProducto controlProd = new ControllerProducto();
        String iva = "";
        String categoria = "";
        iva = jComboBox_iva.getSelectedItem().toString().trim();
        categoria = jComboBox_categoria.getSelectedItem().toString().trim();

        if (txt_nombre.getText().equals("") && txt_stock.getText().equals("") && txt_precio.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Complete todos los campos");

        } else {
            if (!controlProd.existeProducto(txt_nombre.getText().trim())) {
                if (iva.equalsIgnoreCase("Seleccione iva:")) {
                    JOptionPane.showMessageDialog(null, "Seleccione el iva");
                } else {
                    if (categoria.equalsIgnoreCase("Seleccione Categoria:")) {
                        JOptionPane.showMessageDialog(null, "Seleccione la categoria");
                    } else {
                        try {
                            prod.setNombre(txt_nombre.getText().trim());
                            prod.setStock(Integer.parseInt(txt_stock.getText().trim()));
                            String precioTXT = "";
                            double precio = 0.0;
                            precioTXT = txt_precio.getText().trim();
                            boolean aux = false;

                            for (int i = 0; i < precioTXT.length(); i++) {
                                if (precioTXT.charAt(i) == ',') {
                                    String precioNuevo = precioTXT.replace(",", ".");
                                    aux = true;
                                }
                            }

                            if (aux == true) {
                                prod.setValor(precio);
                            } else {
                                precio = Double.parseDouble(precioTXT);
                                prod.setValor(precio);
                            }

                            prod.setDescripcion(txt_descripcion.getText().trim());
                            if (iva.equalsIgnoreCase("No grava iva")) {
                                prod.setPorcentajeIva(0);
                            } else if (iva.equalsIgnoreCase("10.5%")) {
                                prod.setPorcentajeIva(10.5);

                            } else if (iva.equalsIgnoreCase("21%")) {
                                prod.setPorcentajeIva(21);
                            } else if (iva.equalsIgnoreCase("27%")) {
                                prod.setPorcentajeIva(27);
                            }

                            idCateg = controlProd.traerIdCateg(categoria);
                            prod.setIdCategoria(idCateg);
                            prod.setEstado(1);

                            if (controlProd.guardar(prod)) {
                                JOptionPane.showMessageDialog(null, "Registro guardado");
                                this.cargarCategorias();
                                this.Limpiar();

                            } else {

                                JOptionPane.showMessageDialog(null, "Error al guardar");
                            }
                        } catch (HeadlessException | NumberFormatException e) {
                            System.out.println("Error en " + e);
                        }
                    }
                }
            }
        }

    }//GEN-LAST:event_jButton_guardarProductoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_guardarProducto;
    private javax.swing.JComboBox<String> jComboBox_categoria;
    private javax.swing.JComboBox<String> jComboBox_iva;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel_wallPaper;
    private javax.swing.JTextField txt_descripcion;
    private javax.swing.JTextField txt_nombre;
    private javax.swing.JTextField txt_precio;
    private javax.swing.JTextField txt_stock;
    // End of variables declaration//GEN-END:variables
    private void Limpiar() {
        txt_nombre.setText("");
        txt_stock.setText("");
        txt_precio.setText("");
        txt_descripcion.setText("");
        jComboBox_categoria.setSelectedItem("Seleccione Categoria:");
        jComboBox_iva.setSelectedItem("Seleccione iva:");
    }

    private void cargarCategorias() {
        try {
            ControllerProducto controller = new ControllerProducto();
            List<String> categorias = controller.cargarListCategorias(); 
            this.jComboBox_categoria.removeAllItems();
            this.jComboBox_categoria.addItem("Seleccione categoria:");
            for (String categ : categorias) {
                this.jComboBox_categoria.addItem(categ); 
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar datos: " + e.getMessage());
        }
    }

}
