/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package vista.Gerente;

import Controlador.ControllerProducto;
import java.awt.Dimension;
import java.util.List;
import javax.swing.JOptionPane;
import modelo.Entitys.Productos;

/**
 *
 * @author Martina
 */
public class InterActualizarStock extends javax.swing.JInternalFrame {

    Productos prod=new Productos();
    ControllerProducto controller = new ControllerProducto();
int idProd=0;
    
    public InterActualizarStock() {
        initComponents();
        setTitle("Actualizar Stock de los productos");
        setSize(new Dimension(400, 300));
        this.cargarProductos();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel7 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txt_cantidadActual = new javax.swing.JTextField();
        txt_stockNuevo = new javax.swing.JTextField();
        jComboBox_producto = new javax.swing.JComboBox<>();
        jButton_actualizar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel_wallPaper = new javax.swing.JLabel();

        jLabel7.setText("jLabel7");

        jTextField1.setText("jTextField1");

        setBackground(new java.awt.Color(204, 204, 204));
        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Actualizar Stock");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, 180, -1));

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Stock nuevo:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, -1, 20));

        txt_cantidadActual.setBackground(new java.awt.Color(255, 255, 255));
        txt_cantidadActual.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        txt_cantidadActual.setForeground(new java.awt.Color(0, 0, 0));
        txt_cantidadActual.setEnabled(false);
        getContentPane().add(txt_cantidadActual, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 90, 200, -1));

        txt_stockNuevo.setBackground(new java.awt.Color(255, 255, 255));
        txt_stockNuevo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        txt_stockNuevo.setForeground(new java.awt.Color(0, 0, 0));
        txt_stockNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_stockNuevoActionPerformed(evt);
            }
        });
        getContentPane().add(txt_stockNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 130, 200, -1));

        jComboBox_producto.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_producto.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jComboBox_producto.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_producto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione producto:", "Item 2", "Item 3", "Item 4" }));
        jComboBox_producto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_productoActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox_producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 50, 200, -1));

        jButton_actualizar.setBackground(new java.awt.Color(153, 255, 153));
        jButton_actualizar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton_actualizar.setForeground(new java.awt.Color(51, 51, 51));
        jButton_actualizar.setText("Actualizar");
        jButton_actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_actualizarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 180, 120, 30));

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Stock actual:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Producto:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 70, -1));

        jLabel_wallPaper.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel_wallPaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondo3.jpg"))); // NOI18N
        getContentPane().add(jLabel_wallPaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 390, 270));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox_productoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_productoActionPerformed
        this.cargarStock((String) jComboBox_producto.getSelectedItem());
    }//GEN-LAST:event_jComboBox_productoActionPerformed

    private void txt_stockNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_stockNuevoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_stockNuevoActionPerformed

    private void jButton_actualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_actualizarActionPerformed
        if (!jComboBox_producto.getSelectedItem().equals("Seleccione producto:")) {

            if (!txt_stockNuevo.getText().isEmpty()) {

                boolean validacion=this.validar(txt_stockNuevo.getText().trim());
                if (validacion) {
                    if(Integer.parseInt(txt_stockNuevo.getText())>0){
                        int stockActual=Integer.parseInt(txt_cantidadActual.getText().trim());
                        int stockNuevo=Integer.parseInt(txt_stockNuevo.getText().trim());
                        stockNuevo=stockActual+stockNuevo;
                        prod.setStock(stockNuevo);
                        idProd=controller.traerId((String) jComboBox_producto.getSelectedItem());
                        if(controller.ActualizarStock(prod, idProd)){
                            JOptionPane.showMessageDialog(null, "Actualizado");
                            this.limpiar();
                            this.cargarProductos();
                    
                        }else{
                            JOptionPane.showMessageDialog(null, "Error al actualizar");
                    
                        }
                    }else{
                        JOptionPane.showMessageDialog(null, "La cantidad debe ser mayor a 0");
                    }

                } else {
                    JOptionPane.showMessageDialog(null, "Solo se admiten numeros");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Ingrese la cantidad a sumar");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Selecciona un producto");
        }
    }//GEN-LAST:event_jButton_actualizarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_actualizar;
    private javax.swing.JComboBox<String> jComboBox_producto;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel_wallPaper;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField txt_cantidadActual;
    private javax.swing.JTextField txt_stockNuevo;
    // End of variables declaration//GEN-END:variables
 
     private void limpiar() {
        txt_cantidadActual.setText("");
        txt_stockNuevo.setText("");
 jComboBox_producto.setSelectedItem("Seleccione producto:");
        
    }
    private void cargarProductos() {
        try {

            List<String> prods = controller.cargarComboProds();
            this.jComboBox_producto.removeAllItems();
            this.jComboBox_producto.addItem("Seleccione producto:");
            for (String prod : prods) {
                this.jComboBox_producto.addItem(prod);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar datos: " + e.getMessage());
        }
    }

    private void cargarStock(String nombreProd) {
        
        txt_cantidadActual.setText(String.valueOf(controller.mostrarStock(nombreProd)));
        idProd=controller.traerId(nombreProd);
    }

    private boolean validar(String valor) {
        int num;
        try {

            num = Integer.parseInt(valor);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }

    }
}
