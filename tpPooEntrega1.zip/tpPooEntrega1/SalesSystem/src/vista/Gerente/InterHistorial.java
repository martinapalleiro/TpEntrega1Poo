
package vista.Gerente;

import Controlador.ControllerPedidosDetalles;
import java.awt.Dimension;
import java.util.List;
import java.util.Map;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import static vista.Gerente.FrmMenuGerente.jDesktopPane_menu;




public class InterHistorial extends javax.swing.JInternalFrame {

    public static String fecha_inicio = "", fecha_fin = "";
    public ControllerPedidosDetalles ctrPedidos = new ControllerPedidosDetalles();
    
    public InterHistorial() {
        initComponents();
        
        this.CargarVentas();
        this.setSize(new Dimension(599, 502));
        this.setTitle("Historial de Ventas");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton_mostrarVentas = new javax.swing.JButton();
        jDateChooser_fechaFin = new com.toedter.calendar.JDateChooser();
        jDateChooser_fechaInicio = new com.toedter.calendar.JDateChooser();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_historial = new javax.swing.JTable();
        jLabel_wallPaper = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Seleccione fechas para mostrar");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 20, -1, -1));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Fecha inicio:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, -1, -1));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText(" Fecha fin:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 70, -1, -1));

        jButton_mostrarVentas.setBackground(new java.awt.Color(204, 204, 255));
        jButton_mostrarVentas.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton_mostrarVentas.setForeground(new java.awt.Color(0, 0, 0));
        jButton_mostrarVentas.setText("Mostrar Tabla");
        jButton_mostrarVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_mostrarVentasActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_mostrarVentas, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 110, 180, 30));

        jDateChooser_fechaFin.setBackground(new java.awt.Color(255, 255, 255));
        jDateChooser_fechaFin.setDateFormatString("yyyy-MM-dd");
        jDateChooser_fechaFin.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        getContentPane().add(jDateChooser_fechaFin, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 60, 150, -1));

        jDateChooser_fechaInicio.setBackground(new java.awt.Color(255, 255, 255));
        jDateChooser_fechaInicio.setDateFormatString("yyyy-MM-dd");
        jDateChooser_fechaInicio.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        getContentPane().add(jDateChooser_fechaInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 60, 150, -1));

        jTable_historial.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTable_historial.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable_historial);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 590, 300));

        jLabel_wallPaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondo3.jpg"))); // NOI18N
        getContentPane().add(jLabel_wallPaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -120, 590, 650));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_mostrarVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_mostrarVentasActionPerformed

        fecha_inicio = ((JTextField) jDateChooser_fechaInicio.getDateEditor().getUiComponent()).getText();
        fecha_fin = ((JTextField) jDateChooser_fechaFin.getDateEditor().getUiComponent()).getText();
        System.out.println(fecha_inicio+ "y "+fecha_fin);
        
        this.CargarVentas();

    }//GEN-LAST:event_jButton_mostrarVentasActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_mostrarVentas;
    private com.toedter.calendar.JDateChooser jDateChooser_fechaFin;
    private com.toedter.calendar.JDateChooser jDateChooser_fechaInicio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel_wallPaper;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_historial;
    // End of variables declaration//GEN-END:variables
private void CargarVentas() {
        
        
        List<Map<String, Object>> historialVentas = ctrPedidos.CargarHistorial(fecha_inicio,fecha_fin);
        DefaultTableModel model = new DefaultTableModel();

        model.addColumn("Fecha");
        model.addColumn("Cliente");
        model.addColumn("Total");

        for (Map<String, Object> venta : historialVentas) {
            Object[] fila = new Object[3];  // Cantidad de columnas

            fila[0] = venta.get("fechaVenta");       // Fecha de la venta
            fila[1] = venta.get("nombreCliente");    // Nombre del cliente
            fila[2] = venta.get("total");   

            model.addRow(fila);
        }
        jTable_historial = new JTable(model);
        jScrollPane1.setViewportView(jTable_historial);
}
}
