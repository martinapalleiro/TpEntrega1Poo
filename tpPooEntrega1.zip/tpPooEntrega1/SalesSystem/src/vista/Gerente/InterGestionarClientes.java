package vista.Gerente;

import Controlador.ControllerCliente;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelo.Entitys.Cliente;

public class InterGestionarClientes extends javax.swing.JInternalFrame {

    public ControllerCliente gestionCliente;
    private int idCliente;

    public InterGestionarClientes() {
         initComponents();
        this.setSize(new Dimension(900, 500));
        this.setTitle("Gestionar Clientes");

        this.gestionCliente = new Controlador.ControllerCliente();
        CargarClientes();
        ImageIcon wallPaper = new ImageIcon("src/img/fondo3.jpg");
        Icon icono = new ImageIcon(wallPaper.getImage().getScaledInstance(900, 500, WIDTH));
        jLabel_wallPaper.setIcon(icono);
        this.repaint();

        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSplitPane1 = new javax.swing.JSplitPane();
        jPanel2 = new javax.swing.JPanel();
        jButton_actualizar = new javax.swing.JButton();
        jButton_eliminar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_clientes = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txt_nombre = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txt_dni = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txt_apellido = new javax.swing.JTextField();
        txt_domicilio = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txt_celular = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel_wallPaper = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel2.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton_actualizar.setBackground(new java.awt.Color(204, 255, 204));
        jButton_actualizar.setForeground(new java.awt.Color(0, 0, 0));
        jButton_actualizar.setText("Actualizar");
        jButton_actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_actualizarActionPerformed(evt);
            }
        });
        jPanel2.add(jButton_actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 100, -1));

        jButton_eliminar.setBackground(new java.awt.Color(255, 204, 204));
        jButton_eliminar.setForeground(new java.awt.Color(0, 0, 0));
        jButton_eliminar.setText("Eliminar");
        jButton_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_eliminarActionPerformed(evt);
            }
        });
        jPanel2.add(jButton_eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 100, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 60, 140, 250));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable_clientes.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTable_clientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable_clientes);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 640, 230));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 680, 250));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel2.setText("Nombre:");
        jLabel2.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 80, 20));

        txt_nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nombreActionPerformed(evt);
            }
        });
        jPanel3.add(txt_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, 170, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("DNI:");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 20, -1, -1));

        txt_dni.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_dniActionPerformed(evt);
            }
        });
        jPanel3.add(txt_dni, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 20, 180, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Apellido:");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Celular:");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 60, -1, -1));
        jPanel3.add(txt_apellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 60, 170, -1));
        jPanel3.add(txt_domicilio, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 60, 180, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Domicilio:");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 30, -1, -1));
        jPanel3.add(txt_celular, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 60, 180, -1));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, 840, 130));

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Gestionar Clientes");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 0, 170, 50));
        getContentPane().add(jLabel_wallPaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 890, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_eliminarActionPerformed
        if (idCliente == 0) {

            JOptionPane.showMessageDialog(null, "Seleccione un cliente");

        } else {
            if (!gestionCliente.eliminar(idCliente)) {

                JOptionPane.showMessageDialog(null, "Cliente eliminado");
                CargarClientes();
                this.Limpiar();

            } else {

                JOptionPane.showMessageDialog(null, "Error al eliminar cliente");
            }
        }
    }//GEN-LAST:event_jButton_eliminarActionPerformed

    private void txt_nombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nombreActionPerformed

    private void txt_dniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_dniActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_dniActionPerformed

    private void jButton_actualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_actualizarActionPerformed

       
        if (txt_nombre.getText().isEmpty() && txt_apellido.getText().isEmpty() && txt_dni.getText().isEmpty() && txt_celular.getText().isEmpty() && txt_domicilio.getText().isEmpty()) {

            JOptionPane.showMessageDialog(null, "Completa todos los campos");
        } else {

            Cliente cliente = new Cliente();
            
            cliente.setNombre(txt_nombre.getText().trim());
            cliente.setApellido(txt_apellido.getText().trim());
            cliente.setDni(Long.parseLong(txt_dni.getText().trim()));
            cliente.setCelular(txt_celular.getText().trim());
            cliente.setDomicilio(txt_domicilio.getText().trim());

            if (this.gestionCliente.actualizar(cliente, idCliente)) {
                JOptionPane.showMessageDialog(null, "Cliente actualizado");
                CargarClientes();
                this.Limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al actualizar");

            }
        }
    }//GEN-LAST:event_jButton_actualizarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_actualizar;
    private javax.swing.JButton jButton_eliminar;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel_wallPaper;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JTable jTable_clientes;
    private javax.swing.JTextField txt_apellido;
    private javax.swing.JTextField txt_celular;
    private javax.swing.JTextField txt_dni;
    private javax.swing.JTextField txt_domicilio;
    private javax.swing.JTextField txt_nombre;
    // End of variables declaration//GEN-END:variables
    private void Limpiar() {
        txt_nombre.setText("");
        txt_apellido.setText("");
        txt_dni.setText("");
        txt_celular.setText("");
        txt_domicilio.setText("");
    }

    private void CargarClientes() {
    ArrayList<Cliente> clientes = gestionCliente.CargarClientes();
    DefaultTableModel model = new DefaultTableModel();

    model.addColumn("ID");
    model.addColumn("Nombre");
    model.addColumn("Apellido");
    model.addColumn("Dni");
    model.addColumn("Celular");
    model.addColumn("Domicilio");

    for (Cliente cliente : clientes) {
        Object fila[] = new Object[6];
        idCliente = cliente.getIdCliente();
        fila[0] = idCliente;
        fila[1] = cliente.getNombre();
        fila[2] = cliente.getApellido();
        fila[3] = cliente.getDni();
        fila[4] = cliente.getCelular();
        fila[5] = cliente.getDomicilio();
        model.addRow(fila);
    }

    jTable_clientes = new JTable(model);
    jScrollPane1.setViewportView(jTable_clientes);

    jTable_clientes.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
            int fila_point = jTable_clientes.rowAtPoint(e.getPoint());
            int columna_point = 0;

            if (fila_point >= 0) {
                idCliente = (int) model.getValueAt(fila_point, columna_point);
                EnviarDatosClienteSeleccionado(idCliente);
                System.out.println("entro al if del mouseclicked");
            }
        }

        private Cliente EnviarDatosClienteSeleccionado(int idCliente) {
            Cliente cliente = gestionCliente.getClienteSeleccionado(idCliente);
            MostrarDatosCliente(cliente);
            System.out.println("enviarDatoCliente");
            return cliente;
        }
    });
}

public void MostrarDatosCliente(Cliente cliente) {
    System.out.println("mostrar datos cliente");
    if (cliente != null) {
        txt_nombre.setText(cliente.getNombre());
        txt_apellido.setText(cliente.getApellido());
        txt_dni.setText(Long.toString(cliente.getDni()));
        txt_celular.setText(cliente.getCelular());
        txt_domicilio.setText(cliente.getDomicilio());
    }

    System.out.println(txt_nombre.getText());
}
}
