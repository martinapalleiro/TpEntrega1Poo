/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package vista.Cajero;


import Controlador.ControllerUsuario;
import java.awt.Dimension;
import static java.awt.image.ImageObserver.WIDTH;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author Martina
 */
public class InterUsuario extends javax.swing.JInternalFrame {

    /**
     * Creates new form InterProducto
     */
    public InterUsuario() {
        initComponents();
        
        this.setSize(new Dimension(400,400));
        this.setTitle("Nuevo Usuario");
        
        ImageIcon wallPaper = new ImageIcon("src/img/fondo3.jpg");
        Icon icono = new ImageIcon (wallPaper.getImage().getScaledInstance(400, 400, WIDTH));
        jLabel_wallPaper.setIcon(icono);
        this.repaint();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txt_dni = new javax.swing.JTextField();
        txt_apellido = new javax.swing.JTextField();
        txt_celular = new javax.swing.JTextField();
        jButton_guardarUsuario = new javax.swing.JButton();
        txt_usuario = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txt_nombre = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txt_domicilio = new javax.swing.JTextField();
        jCheckBox_verClave = new javax.swing.JCheckBox();
        txt_contra = new javax.swing.JPasswordField();
        jComboBox_puesto = new javax.swing.JComboBox<>();
        txt_contraVisible = new javax.swing.JTextField();
        jLabel_wallPaper = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nuevo usuario");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 10, -1, -1));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("DNI:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, -1, 20));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Apellido:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, -1, -1));

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Celular:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 170, -1, -1));

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Usuario:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, -1, -1));

        txt_dni.setBackground(new java.awt.Color(255, 255, 255));
        txt_dni.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(txt_dni, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 140, 190, -1));

        txt_apellido.setBackground(new java.awt.Color(255, 255, 255));
        txt_apellido.setForeground(new java.awt.Color(0, 0, 0));
        txt_apellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_apellidoActionPerformed(evt);
            }
        });
        getContentPane().add(txt_apellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 110, 190, -1));

        txt_celular.setBackground(new java.awt.Color(255, 255, 255));
        txt_celular.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(txt_celular, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 170, 190, -1));

        jButton_guardarUsuario.setBackground(new java.awt.Color(204, 204, 255));
        jButton_guardarUsuario.setForeground(new java.awt.Color(0, 0, 0));
        jButton_guardarUsuario.setText("Guardar");
        jButton_guardarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_guardarUsuarioActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_guardarUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 320, -1, -1));

        txt_usuario.setBackground(new java.awt.Color(255, 255, 255));
        txt_usuario.setForeground(new java.awt.Color(0, 0, 0));
        txt_usuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_usuarioActionPerformed(evt);
            }
        });
        getContentPane().add(txt_usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 230, 190, -1));

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Puesto:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 50, -1, -1));

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Nombre:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 80, -1, -1));

        txt_nombre.setBackground(new java.awt.Color(255, 255, 255));
        txt_nombre.setForeground(new java.awt.Color(0, 0, 0));
        txt_nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nombreActionPerformed(evt);
            }
        });
        getContentPane().add(txt_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, 190, -1));

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Contraseña:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 260, -1, -1));

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Domicilio:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 200, -1, -1));

        txt_domicilio.setBackground(new java.awt.Color(255, 255, 255));
        txt_domicilio.setForeground(new java.awt.Color(0, 0, 0));
        txt_domicilio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_domicilioActionPerformed(evt);
            }
        });
        getContentPane().add(txt_domicilio, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 200, 190, -1));

        jCheckBox_verClave.setBackground(new java.awt.Color(255, 255, 255));
        jCheckBox_verClave.setForeground(new java.awt.Color(255, 255, 255));
        jCheckBox_verClave.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jCheckBox_verClaveMouseClicked(evt);
            }
        });
        jCheckBox_verClave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox_verClaveActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox_verClave, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 260, 20, 30));

        txt_contra.setBackground(new java.awt.Color(255, 255, 255));
        txt_contra.setForeground(new java.awt.Color(0, 0, 0));
        txt_contra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_contraActionPerformed(evt);
            }
        });
        getContentPane().add(txt_contra, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 260, 190, -1));

        jComboBox_puesto.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_puesto.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_puesto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione Puesto", "Cajero", "Armador de pedidos", "Gerente" }));
        jComboBox_puesto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_puestoActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox_puesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 50, 190, -1));

        txt_contraVisible.setBackground(new java.awt.Color(255, 255, 255));
        txt_contraVisible.setForeground(new java.awt.Color(0, 0, 0));
        txt_contraVisible.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_contraVisibleActionPerformed(evt);
            }
        });
        getContentPane().add(txt_contraVisible, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 260, 190, -1));

        jLabel_wallPaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondo3.jpg"))); // NOI18N
        getContentPane().add(jLabel_wallPaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 390, 360));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_apellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_apellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_apellidoActionPerformed

    private void jButton_guardarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_guardarUsuarioActionPerformed
        if (txt_nombre.getText().isEmpty() || txt_apellido.getText().isEmpty() || txt_dni.getText().isEmpty()
            || txt_celular.getText().isEmpty() || txt_domicilio.getText().isEmpty() || txt_usuario.getText().isEmpty()
            || txt_contra.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Completa todos los datos");
        } else {
            String puesto = (String) jComboBox_puesto.getSelectedItem();
            String nombre = txt_nombre.getText().trim();
            String apellido = txt_apellido.getText().trim();
            String dniString = txt_dni.getText().trim();
            String celular = txt_celular.getText().trim();
            String domicilio = txt_domicilio.getText().trim();
            String usuario = txt_usuario.getText().trim();
            String contra = txt_contra.getText().trim();

            if (dniString.matches("\\d+")) {
                long dni = Long.parseLong(dniString);

                ControllerUsuario controladorUsuario = new ControllerUsuario();
                if (controladorUsuario.registrarUsuario(puesto, nombre, apellido, dni, celular, domicilio, usuario, contra)) {
                    JOptionPane.showMessageDialog(null, "Usuario registrado");
                    this.Limpiar();
                } else {
                    JOptionPane.showMessageDialog(null, "El usuario ya está registrado o hubo un error en el registro.");
                }
            } else {
                JOptionPane.showMessageDialog(null, "El texto no es un número válido: " + dniString);
            }
        }
    }//GEN-LAST:event_jButton_guardarUsuarioActionPerformed

    private void txt_usuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_usuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_usuarioActionPerformed

    private void txt_nombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nombreActionPerformed

    private void txt_domicilioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_domicilioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_domicilioActionPerformed

    private void jCheckBox_verClaveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jCheckBox_verClaveMouseClicked
        boolean isSelected = jCheckBox_verClave.isSelected();
        ControllerUsuario controladorUsuario = new ControllerUsuario();
        controladorUsuario.passwordVisibility(isSelected, txt_contra, txt_contraVisible);
    }//GEN-LAST:event_jCheckBox_verClaveMouseClicked

    private void jCheckBox_verClaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox_verClaveActionPerformed

    }//GEN-LAST:event_jCheckBox_verClaveActionPerformed

    private void txt_contraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_contraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_contraActionPerformed

    private void jComboBox_puestoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_puestoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox_puestoActionPerformed

    private void txt_contraVisibleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_contraVisibleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_contraVisibleActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_guardarUsuario;
    private javax.swing.JCheckBox jCheckBox_verClave;
    private javax.swing.JComboBox<String> jComboBox_puesto;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel_wallPaper;
    private javax.swing.JTextField txt_apellido;
    private javax.swing.JTextField txt_celular;
    private javax.swing.JPasswordField txt_contra;
    private javax.swing.JTextField txt_contraVisible;
    private javax.swing.JTextField txt_dni;
    private javax.swing.JTextField txt_domicilio;
    private javax.swing.JTextField txt_nombre;
    private javax.swing.JTextField txt_usuario;
    // End of variables declaration//GEN-END:variables
 private void Limpiar() {
        txt_nombre.setText("");
        txt_apellido.setText("");
        txt_apellido.setText("");
        txt_dni.setText("");
        txt_celular.setText("");
        txt_domicilio.setText("");
        txt_usuario.setText("");
        txt_contra.setText("");
        txt_contraVisible.setText("");
        jComboBox_puesto.setSelectedItem("Seleccione Puesto");

    }}

