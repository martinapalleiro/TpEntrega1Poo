
package vista.Cajero;

import java.awt.Dimension;
import javax.swing.JDesktopPane;


public class FrmMenuCajero extends javax.swing.JFrame {

    public static JDesktopPane jDesktopPane_menu;
    public FrmMenuCajero() {
        initComponents();
        this.setSize(new Dimension(1200, 700));
        this.setExtendedState(this.MAXIMIZED_BOTH);
        this.setLocationRelativeTo(null);
        this.setTitle("Sistema de Ventas");
        this.setLayout(null);
        jDesktopPane_menu = new JDesktopPane();
        
        int ancho=java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
        int alto=java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;
        this.jDesktopPane_menu.setBounds(0,0,ancho,(alto-110));
        this.add(jDesktopPane_menu);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu_usuario = new javax.swing.JMenu();
        jMenuItem_nuevoUsuario = new javax.swing.JMenuItem();
        jMenuItem_gestionarUsuario = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem_gestionarProductos = new javax.swing.JMenuItem();
        jMenu_cliente = new javax.swing.JMenu();
        jMenuItem_nuevoCliente = new javax.swing.JMenuItem();
        jMenuItem_gestionarClientes = new javax.swing.JMenuItem();
        jMenu_facturar = new javax.swing.JMenu();
        jMenuItem_nuevaVenta = new javax.swing.JMenuItem();
        jMenuItem_gestionarVentas = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        jMenuItem_verHistorial = new javax.swing.JMenuItem();
        jMenu_cerrarSesion = new javax.swing.JMenu();
        jMenuItem_cerrarSesion = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jMenu_usuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/usuario.png"))); // NOI18N
        jMenu_usuario.setText("Usuario");
        jMenu_usuario.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jMenu_usuario.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_nuevoUsuario.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_nuevoUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/nuevo-cliente.png"))); // NOI18N
        jMenuItem_nuevoUsuario.setText("Nuevo Usuario");
        jMenuItem_nuevoUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_nuevoUsuarioActionPerformed(evt);
            }
        });
        jMenu_usuario.add(jMenuItem_nuevoUsuario);

        jMenuItem_gestionarUsuario.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_gestionarUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/configuraciones.png"))); // NOI18N
        jMenuItem_gestionarUsuario.setText("Gestionar Usuario");
        jMenuItem_gestionarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_gestionarUsuarioActionPerformed(evt);
            }
        });
        jMenu_usuario.add(jMenuItem_gestionarUsuario);

        jMenuBar1.add(jMenu_usuario);

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/producto.png"))); // NOI18N
        jMenu2.setText("Productos");
        jMenu2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jMenu2.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_gestionarProductos.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_gestionarProductos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/producto.png"))); // NOI18N
        jMenuItem_gestionarProductos.setText("Gestionar Productos");
        jMenuItem_gestionarProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_gestionarProductosActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem_gestionarProductos);

        jMenuBar1.add(jMenu2);

        jMenu_cliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cliente.png"))); // NOI18N
        jMenu_cliente.setText("Cliente");
        jMenu_cliente.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jMenu_cliente.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_nuevoCliente.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_nuevoCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/nuevo-cliente.png"))); // NOI18N
        jMenuItem_nuevoCliente.setText("Nuevo Cliente");
        jMenuItem_nuevoCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_nuevoClienteActionPerformed(evt);
            }
        });
        jMenu_cliente.add(jMenuItem_nuevoCliente);

        jMenuItem_gestionarClientes.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_gestionarClientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cliente.png"))); // NOI18N
        jMenuItem_gestionarClientes.setText("Gestionar Clientes");
        jMenuItem_gestionarClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_gestionarClientesActionPerformed(evt);
            }
        });
        jMenu_cliente.add(jMenuItem_gestionarClientes);

        jMenuBar1.add(jMenu_cliente);

        jMenu_facturar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/carrito.png"))); // NOI18N
        jMenu_facturar.setText("Facturar");
        jMenu_facturar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jMenu_facturar.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_nuevaVenta.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_nuevaVenta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/anadir.png"))); // NOI18N
        jMenuItem_nuevaVenta.setText("Nueva Venta");
        jMenuItem_nuevaVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_nuevaFacturaActionPerformed(evt);
            }
        });
        jMenu_facturar.add(jMenuItem_nuevaVenta);

        jMenuItem_gestionarVentas.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_gestionarVentas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/configuraciones.png"))); // NOI18N
        jMenuItem_gestionarVentas.setText("Gestionar Ventas");
        jMenuItem_gestionarVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_gestionarVentasActionPerformed(evt);
            }
        });
        jMenu_facturar.add(jMenuItem_gestionarVentas);

        jMenuBar1.add(jMenu_facturar);

        jMenu7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/historial1.png"))); // NOI18N
        jMenu7.setText("Historial");
        jMenu7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jMenu7.setPreferredSize(new java.awt.Dimension(150, 50));

        jMenuItem_verHistorial.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_verHistorial.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/historial1.png"))); // NOI18N
        jMenuItem_verHistorial.setText("Ver Historial");
        jMenuItem_verHistorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_verHistorialActionPerformed(evt);
            }
        });
        jMenu7.add(jMenuItem_verHistorial);

        jMenuBar1.add(jMenu7);

        jMenu_cerrarSesion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cerrar-sesion.png"))); // NOI18N
        jMenu_cerrarSesion.setText("Cerrar Sesion");
        jMenu_cerrarSesion.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jMenu_cerrarSesion.setPreferredSize(new java.awt.Dimension(200, 50));

        jMenuItem_cerrarSesion.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jMenuItem_cerrarSesion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cerrar-sesion.png"))); // NOI18N
        jMenuItem_cerrarSesion.setText("Cerrar Sesion");
        jMenuItem_cerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem_cerrarSesionActionPerformed(evt);
            }
        });
        jMenu_cerrarSesion.add(jMenuItem_cerrarSesion);

        jMenuBar1.add(jMenu_cerrarSesion);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem_nuevoUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_nuevoUsuarioActionPerformed
        
        InterUsuario interUsuario = new InterUsuario();
        jDesktopPane_menu.add(interUsuario);
        interUsuario.setVisible(true);
        
    }//GEN-LAST:event_jMenuItem_nuevoUsuarioActionPerformed

    private void jMenuItem_gestionarClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_gestionarClientesActionPerformed
        InterGestionarClientes interGestionarCliente = new InterGestionarClientes();
        jDesktopPane_menu.add(interGestionarCliente);
        interGestionarCliente.setVisible(true);
    }//GEN-LAST:event_jMenuItem_gestionarClientesActionPerformed

    private void jMenuItem_nuevoClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_nuevoClienteActionPerformed
        InterCliente interCliente = new InterCliente();
        jDesktopPane_menu.add(interCliente);
        interCliente.setVisible(true);
    }//GEN-LAST:event_jMenuItem_nuevoClienteActionPerformed

    private void jMenuItem_gestionarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_gestionarUsuarioActionPerformed
        InterGestionarUsuario interGestionarUsuario = new InterGestionarUsuario();
        jDesktopPane_menu.add(interGestionarUsuario);
        interGestionarUsuario.setVisible(true);
    }//GEN-LAST:event_jMenuItem_gestionarUsuarioActionPerformed

    private void jMenuItem_nuevaFacturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_nuevaFacturaActionPerformed
        InterNuevaFactura interNuevaFactura = new InterNuevaFactura();
        jDesktopPane_menu.add(interNuevaFactura);
        interNuevaFactura.setVisible(true);
    }//GEN-LAST:event_jMenuItem_nuevaFacturaActionPerformed

    private void jMenuItem_gestionarVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_gestionarVentasActionPerformed
        InterGestionarVentas interGestionarVentas = new InterGestionarVentas();
        jDesktopPane_menu.add(interGestionarVentas);
        interGestionarVentas.setVisible(true);
    }//GEN-LAST:event_jMenuItem_gestionarVentasActionPerformed

    private void jMenuItem_cerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_cerrarSesionActionPerformed
          System.exit(0);
    }//GEN-LAST:event_jMenuItem_cerrarSesionActionPerformed

    private void jMenuItem_gestionarProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_gestionarProductosActionPerformed
        InterGestionarProductos interGestProducto=new InterGestionarProductos();
        jDesktopPane_menu.add(interGestProducto);
        interGestProducto.setVisible(true);
    }//GEN-LAST:event_jMenuItem_gestionarProductosActionPerformed

    private void jMenuItem_verHistorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_verHistorialActionPerformed
        InterHistorial interHistorial = new InterHistorial();
        jDesktopPane_menu.add(interHistorial);
        interHistorial.setVisible(true);
    }//GEN-LAST:event_jMenuItem_verHistorialActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmMenuCajero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmMenuCajero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmMenuCajero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmMenuCajero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmMenuCajero().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem_cerrarSesion;
    private javax.swing.JMenuItem jMenuItem_gestionarClientes;
    private javax.swing.JMenuItem jMenuItem_gestionarProductos;
    private javax.swing.JMenuItem jMenuItem_gestionarUsuario;
    private javax.swing.JMenuItem jMenuItem_gestionarVentas;
    private javax.swing.JMenuItem jMenuItem_nuevaVenta;
    private javax.swing.JMenuItem jMenuItem_nuevoCliente;
    private javax.swing.JMenuItem jMenuItem_nuevoUsuario;
    private javax.swing.JMenuItem jMenuItem_verHistorial;
    private javax.swing.JMenu jMenu_cerrarSesion;
    private javax.swing.JMenu jMenu_cliente;
    private javax.swing.JMenu jMenu_facturar;
    private javax.swing.JMenu jMenu_usuario;
    // End of variables declaration//GEN-END:variables
}
