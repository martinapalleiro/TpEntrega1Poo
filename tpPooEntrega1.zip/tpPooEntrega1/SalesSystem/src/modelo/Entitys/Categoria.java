
package modelo.Entitys;

import java.util.Objects;

public class Categoria {
   private int idCategoria;
   private String Descripcion;
   private int estado;

    public Categoria() {
        this.idCategoria =0;
        this.Descripcion = "";
        this.estado = 0;
    }

    public Categoria(int idCategoria, String Descripcion, int estado) {
        this.idCategoria = idCategoria;
        this.Descripcion = Descripcion;
        this.estado = estado;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public int getEstado() {
        return estado;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    
    @Override
    public String toString() {
        return Descripcion; // Solo devuelve la descripción para el ComboBox
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 89 * hash + this.idCategoria;
        hash = 89 * hash + Objects.hashCode(this.Descripcion);
        hash = 89 * hash + this.estado;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Categoria other = (Categoria) obj;
        if (this.idCategoria != other.idCategoria) {
            return false;
        }
        if (this.estado != other.estado) {
            return false;
        }
        return Objects.equals(this.Descripcion, other.Descripcion);
    }
    
   
   
}
