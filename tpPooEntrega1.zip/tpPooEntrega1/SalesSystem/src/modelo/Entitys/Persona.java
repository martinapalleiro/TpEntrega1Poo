
package modelo.Entitys;

import java.util.Objects;

/**
 *
 * @author Martina
 */
public abstract class Persona {
    protected String nombre;
    protected String apellido;
    protected long dni;
    protected String celular;
    protected String domicilio;

    public Persona(String nombre, String apellido, long dni, String celular, String domicilio) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.celular = celular;
        this.domicilio = domicilio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public long getDni() {
        return dni;
    }

    public void setDni(long dni) {
        this.dni = dni;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Persona other = (Persona) obj;
        if (this.dni != other.dni) {
            return false;
        }
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.apellido, other.apellido)) {
            return false;
        }
        if (!Objects.equals(this.celular, other.celular)) {
            return false;
        }
        return Objects.equals(this.domicilio, other.domicilio);
    }

   

   
    

    
    @Override
    public String toString() {
        return "Persona{" + "Nombre=" + nombre + ", Apellido=" + apellido + ", dni=" + dni + ", celular=" + celular + ", domicilio=" + domicilio + '}';
    }
    
    
    
}
