
package modelo.Entitys;

/**
 *
 * @author Martina
 */
public class Cliente extends Persona {
    private int idCliente;
    private int idPedido;

    public Cliente(int idCliente, int idPedido, String nombre, String apellido, long dni, String celular, String domicilio) {
        super(nombre, apellido, dni, celular, domicilio);
        this.idCliente = idCliente;
        this.idPedido = idPedido;
    }
    public Cliente() {
        super("", "", 0, "", ""); 
        this.idCliente = 0;
        this.idPedido = 0;

    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }


    

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 19 * hash + this.idCliente;
        hash = 19 * hash + this.idPedido;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cliente other = (Cliente) obj;
        if (this.idCliente != other.idCliente) {
            return false;
        }
        return this.idPedido == other.idPedido;
    }

   

    

    @Override
    public String toString() {
        return "Cliente{" + "idCliente=" + idCliente + ", idPedido=" + idPedido + '}';
    }
    
    
}
