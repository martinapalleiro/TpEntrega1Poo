
package modelo.Entitys;

import modelo.Entitys.Persona;
import java.util.Objects;

public class Usuario extends Persona{
    private int id;
    private String puesto;
    private String usuario;
    private String contra;
    private int estado;

    public Usuario(int id, String puesto, String usuario, String contra, int estado, String nombre, String apellido, long dni, String celular, String domicilio) {
        super(nombre, apellido, dni, celular, domicilio);
        this.id = id;
        this.puesto = puesto;
        this.usuario = usuario;
        this.contra = contra;
        this.estado = estado;
    }

    public Usuario() {
        super("", "", 0, "", "");
        this.id = 0;
        this.puesto = "";
        this.usuario = "";
        this.contra = "";
        this.estado=0;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContra() {
        return contra;
    }

    public void setContra(String contra) {
        this.contra = contra;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String Nombre) {
        this.nombre = Nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String Apellido) {
        this.apellido = Apellido;
    }

    public long getDni() {
        return dni;
    }

    public void setDni(long dni) {
        this.dni = dni;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 61 * hash + this.id;
        hash = 61 * hash + Objects.hashCode(this.puesto);
        hash = 61 * hash + Objects.hashCode(this.usuario);
        hash = 61 * hash + Objects.hashCode(this.contra);
        hash = 61 * hash + this.estado;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        if (this.id != other.id) {
            return false;
        }
        if (this.estado != other.estado) {
            return false;
        }
        if (!Objects.equals(this.puesto, other.puesto)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return Objects.equals(this.contra, other.contra);
    }

    @Override
    public String toString() {
        return "Usuario{" + "id=" + id + ", puesto=" + puesto + ", usuario=" + usuario + ", contra=" + contra + ", estado=" + estado + '}';
    }
    
    
    
    
}
