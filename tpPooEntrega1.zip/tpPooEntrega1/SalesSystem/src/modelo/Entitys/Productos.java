
package modelo.Entitys;

import java.util.Objects;

/**
 *
 * @author Martina
 */
public class Productos {
  private int idProducto;
    private String nombre;
    private String descripcion;
    private int stock;
    private double valor;
    private double porcentajeIva;
    private double iva;
    private int idCategoria;
    private int estado;

    public Productos(int idProducto, String nombre, String descripcion, int stock, double valor,double porcentajeIva, double iva, int idCategoria, int estado) {
        this.idProducto = idProducto;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.stock = stock;
        this.valor = valor;
        this.porcentajeIva = porcentajeIva;
        this.iva = iva;
        this.idCategoria = idCategoria;
        this.estado = estado;
    }

     public Productos() {
        this.idProducto = 0;
        this.nombre = "";
        this.descripcion = "";
        this.stock = 0;
        this.valor = 0.0;
        this.porcentajeIva=0.0;
        this.iva=0.0;
        this.idCategoria = 0;
        this.estado=0;
    }
    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public double getPorcentajeIva() {
        return porcentajeIva;
    }

    public void setPorcentajeIva(double porcentajeIva) {
        this.porcentajeIva = porcentajeIva;
    }

    public double getIva() {
        return iva;
    }

    public void setIva(double iva) {
        this.iva = iva;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 23 * hash + this.idProducto;
        hash = 23 * hash + Objects.hashCode(this.nombre);
        hash = 23 * hash + Objects.hashCode(this.descripcion);
        hash = 23 * hash + this.stock;
        hash = 23 * hash + (int) (Double.doubleToLongBits(this.valor) ^ (Double.doubleToLongBits(this.valor) >>> 32));
        hash = 23 * hash + (int) (Double.doubleToLongBits(this.porcentajeIva) ^ (Double.doubleToLongBits(this.porcentajeIva) >>> 32));
        hash = 23 * hash + (int) (Double.doubleToLongBits(this.iva) ^ (Double.doubleToLongBits(this.iva) >>> 32));
        hash = 23 * hash + this.idCategoria;
        hash = 23 * hash + this.estado;
        return hash;
    }

    

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Productos other = (Productos) obj;
        if (this.idProducto != other.idProducto) {
            return false;
        }
        if (this.stock != other.stock) {
            return false;
        }
        if (Double.doubleToLongBits(this.valor) != Double.doubleToLongBits(other.valor)) {
            return false;
        }
        if (this.porcentajeIva != other.porcentajeIva) {
            return false;
        }
        if (Double.doubleToLongBits(this.iva) != Double.doubleToLongBits(other.iva)) {
            return false;
        }
        if (this.idCategoria != other.idCategoria) {
            return false;
        }
        if (this.estado != other.estado) {
            return false;
        }
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        return Objects.equals(this.descripcion, other.descripcion);
    }

    @Override
    public String toString() {
        return "Productos{" + "idProducto=" + idProducto + ", nombre=" + nombre + ", descripcion=" + descripcion + ", stock=" + stock + ", valor=" + valor + ", porcentajeIva=" + porcentajeIva + ", iva=" + iva + ", idCategoria=" + idCategoria + ", estado=" + estado + '}';
    }
    
    
    

   
    
}
