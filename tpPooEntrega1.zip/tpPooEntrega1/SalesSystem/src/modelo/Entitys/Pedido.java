
package modelo.Entitys;

import java.util.Objects;

/**
 *
 * @author Martina
 */
public class Pedido {
    private int idPedido;
    private int idCliente;
    private String cliente;
    private double Total;
    private String fechaVenta;
    private int estado;

    public Pedido(int idPedido, int idCliente, String cliente, double Total, String fechaVenta, int estado) {
        this.idPedido = idPedido;
        this.idCliente = idCliente;
        this.cliente = cliente;
        this.Total = Total;
        this.fechaVenta = fechaVenta;
        this.estado = estado;
    }


    public Pedido() {
        this.idPedido = 0;
        this.idCliente = 0;
        this.cliente="";
        this.Total = 0.0;
        this.fechaVenta = "";
        this.estado = 0;
    }
    

public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public double getTotal() {
        return Total;
    }

    public void setTotal(double Total) {
        this.Total = Total;
    }

    public String getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(String fechaVenta) {
        this.fechaVenta = fechaVenta;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + this.idPedido;
        hash = 29 * hash + this.idCliente;
        hash = 29 * hash + Objects.hashCode(this.cliente);
        hash = 29 * hash + (int) (Double.doubleToLongBits(this.Total) ^ (Double.doubleToLongBits(this.Total) >>> 32));
        hash = 29 * hash + Objects.hashCode(this.fechaVenta);
        hash = 29 * hash + this.estado;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Pedido other = (Pedido) obj;
        if (this.idPedido != other.idPedido) {
            return false;
        }
        if (this.idCliente != other.idCliente) {
            return false;
        }
        if (Double.doubleToLongBits(this.Total) != Double.doubleToLongBits(other.Total)) {
            return false;
        }
        if (this.estado != other.estado) {
            return false;
        }
        if (!Objects.equals(this.cliente, other.cliente)) {
            return false;
        }
        return Objects.equals(this.fechaVenta, other.fechaVenta);
    }

    @Override
    public String toString() {
        return "Pedido{" + "idPedido=" + idPedido + ", idCliente=" + idCliente + ", cliente=" + cliente + ", Total=" + Total + ", fechaVenta=" + fechaVenta + ", estado=" + estado + '}';
    }
    
}
