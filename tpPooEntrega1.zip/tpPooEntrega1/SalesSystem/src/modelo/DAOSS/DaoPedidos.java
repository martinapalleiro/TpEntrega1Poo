

package modelo.DAOSS;

import modelo.Entitys.detallePedido;
import modelo.Entitys.Pedido;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import conexion.conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DaoPedidos {

    public static int idVenta;
    public static int idPedidoRegistrado;
    static java.math.BigDecimal iDColVar;
    
    public static List<Pedido> cargarVentas() {

        List<Pedido> ventas = new ArrayList<>();
        String sql = "SELECT v.idPedido AS id, CONCAT(c.nombre, ' ', c.apellido) AS cliente, "
                + "v.Total AS total, v.fechaVenta AS fecha, v.estado "
                + "FROM tb_ventas AS v, tb_cliente AS c WHERE v.idCliente = c.idCliente;";

        try (Connection con = (Connection) conexion.conectar(); Statement st = (Statement) con.createStatement(); ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Pedido venta = new Pedido();
                venta.setIdCliente(rs.getInt("id"));
                venta.setCliente(rs.getString("cliente"));
                venta.setTotal(rs.getDouble("total"));
                venta.setFechaVenta(rs.getString("fecha"));
                venta.setEstado(rs.getInt("estado"));
                ventas.add(venta);
            }
        } catch (SQLException e) {
            System.out.println("Error al cargar ventas: " + e);
        }
        return ventas;
    }

    public static Pedido enviarDatosVenta(int id) {
        Pedido venta = null;
        String sql = "SELECT v.idPedido AS id, v.idCliente, CONCAT(c.nombre, ' ', c.apellido) AS cliente, "
                + "v.Total, v.fechaVenta AS fecha, v.estado "
                + "FROM tb_ventas AS v, tb_cliente AS c WHERE v.idPedido = ? AND v.idCliente = c.idCliente;";

        try (Connection con = (Connection) conexion.conectar(); PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql)) {

            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                venta = new Pedido();
                venta.setIdPedido(rs.getInt("id"));
                venta.setIdCliente(rs.getInt("idCliente"));
                venta.setCliente(rs.getString("cliente"));
                venta.setTotal(rs.getDouble("Total"));
                venta.setFechaVenta(rs.getString("fecha"));
                venta.setEstado(rs.getInt("estado"));
            }
        } catch (SQLException e) {
            System.out.println("Error al seleccionar venta: " + e);
        }
        return venta;

    }

    public static List<String> cargarClientes() {
        List<String> clientes = new ArrayList<>();
        String sql = "SELECT CONCAT(nombre, ' ', apellido) AS cliente FROM tb_cliente";

        try (Connection cn = (Connection) conexion.conectar(); Statement st = (Statement) cn.createStatement(); ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                clientes.add(rs.getString("cliente"));
            }
        } catch (SQLException e) {
            System.out.println("¡Error al cargar clientes! " + e);
        }
        return clientes;
    }


    public static boolean guardarPedido(Pedido objeto) {
        boolean respuesta = false;
        java.sql.Connection cn = (java.sql.Connection) conexion.conectar();
        try {
            PreparedStatement consulta = (PreparedStatement) cn.prepareStatement("insert into tb_ventas values (?,?,?,?,?)",
                    Statement.RETURN_GENERATED_KEYS);
            consulta.setInt(1, 0);
            consulta.setInt(2, objeto.getIdCliente());
            consulta.setDouble(3, objeto.getTotal());
            consulta.setString(4, objeto.getFechaVenta());
            consulta.setInt(5, objeto.getEstado());
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            ResultSet rs = consulta.getGeneratedKeys();
            while (rs.next()) {
                iDColVar = rs.getBigDecimal(1);
                idPedidoRegistrado = iDColVar.intValue();

            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al guardar Pedido " + e);
        }
        return respuesta;

    }

    public static boolean guardarDetalle(detallePedido objeto) {
        boolean respuesta = false;
        java.sql.Connection cn = (java.sql.Connection) conexion.conectar();
        try {
            PreparedStatement consulta = (PreparedStatement) cn.prepareStatement("insert into tb_detalleVentas values (?,?,?,?,?,?,?,?,?)");
            consulta.setInt(1, 0);
            consulta.setInt(2, idPedidoRegistrado);
            consulta.setInt(3, objeto.getIdProducto());
            consulta.setInt(4, objeto.getCantidad());
            consulta.setDouble(5, objeto.getPrecioUnitario());
            consulta.setDouble(6, objeto.getSubtotal());
            consulta.setDouble(7, objeto.getIva());
            consulta.setDouble(8, objeto.getTotal());
            consulta.setInt(9, objeto.getEstado());
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al guardar los detalles de pedido" + e);
        }
        return respuesta;

    }

    public static boolean actualizarVenta(Pedido objeto, int id) {
        boolean respuesta = false;
        java.sql.Connection cn = conexion.conectar();
        PreparedStatement consulta = null;

        try {
            consulta = (PreparedStatement) cn.prepareStatement(
                    "UPDATE tb_ventas SET idCliente=?, estado=? WHERE idPedido='" + id + "'");

            consulta.setInt(1, objeto.getIdCliente());
            consulta.setInt(2, objeto.getEstado());

            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar venta: " + e);
        } finally {
            try {

                if (consulta != null) {
                    consulta.close();
                }
                if (cn != null) {
                    cn.close();
                }
            } catch (SQLException e) {
                System.out.println("Error al cerrar recursos: " + e);
            }
        }

        return respuesta;
    }

    public static boolean actualizarPedido(String cliente, String estado, int idVenta) {
        boolean resultado = false;
        Pedido pedido = new Pedido();

        try {
            Connection cn = (Connection) conexion.conectar();
            PreparedStatement pst = (PreparedStatement) cn.prepareStatement(
                    "SELECT idCliente FROM tb_cliente WHERE CONCAT(nombre, ' ', apellido) = ?;");
            pst.setString(1, cliente);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                int idCliente = rs.getInt("idCliente");
                pedido.setIdCliente(idCliente);
                pedido.setEstado(estado.equalsIgnoreCase("Entregado") ? 1 : 0);

                resultado = DaoPedidos.actualizarVenta(pedido, idVenta);
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar pedido: " + e);
        }
        return resultado;
    }
}
