
package modelo.DAOSS;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import conexion.conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.Entitys.Cliente;


public class DAOCliente {
    
    public boolean guardar(Cliente objeto){
        
        boolean respuesta = false;
        Connection cn = conexion.conectar();
        try{
            
            PreparedStatement consulta = (PreparedStatement) cn.prepareStatement("insert into tb_cliente values(?,?,?,?,?,?)");
            consulta.setInt(1, 0);//id
            consulta.setString(2, objeto.getNombre());
            consulta.setString(3, objeto.getApellido());
            consulta.setLong(4, objeto.getDni());

            consulta.setString(5, objeto.getCelular());


            consulta.setString(6, objeto.getDomicilio());
            
            if(consulta.executeUpdate() > 0){
                respuesta = true;
            }
            cn.close();
        }catch (SQLException e){
            System.out.println("Error al guardar cliente: " + e);
        }
        
        return respuesta;
    }
    
    public boolean existeCliente(String dni){
        
        boolean respuesta = false;
        String sql = "select dni from tb_cliente where dni= '" + dni + "'";
        Statement st;
        
        try{
            Connection cn = conexion.conectar();
            st = (Statement) cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()){
                respuesta = true;
            }
            
        }catch(SQLException e){
            System.out.println("Error en: " + e);
        }
        return respuesta;
    }
    
     public static ArrayList<Cliente> CargarClientes() {

        ArrayList<Cliente> clientes = new ArrayList();
        String sql = "select* from tb_cliente;";
        try {
            Connection con = conexion.conectar();
            Statement st = (Statement) con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                Cliente cliente = new Cliente();
                cliente.setIdCliente(rs.getInt("idCliente"));
                cliente.setNombre(rs.getString("nombre"));
                cliente.setApellido(rs.getString("apellido"));
                cliente.setDni(rs.getLong("dni"));
                cliente.setCelular(rs.getString("celular"));
                cliente.setDomicilio(rs.getString("domicilio"));
                clientes.add(cliente);

            }

        } catch (SQLException e) {
            System.out.println("Error al cargar tabla clientes " + e);
        }
        return clientes;
    }

    public static Cliente EnviarDatosCliente(int idCliente) {

        Cliente cliente = new Cliente();
        try {
            Connection con = conexion.conectar();
            PreparedStatement pst = (PreparedStatement) con.prepareStatement(
                    "select * from tb_cliente where idCliente = '" + idCliente + "'");
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {

                cliente.setIdCliente(rs.getInt("idCliente"));
                cliente.setNombre(rs.getString("nombre"));
                cliente.setApellido(rs.getString("apellido"));
                cliente.setDni(rs.getLong("dni"));

                cliente.setCelular(rs.getString("celular"));

                cliente.setDomicilio(rs.getString("domicilio"));

            }
        } catch (SQLException e) {
            System.out.println("Error al obtener producto " + e);
        }
        return cliente;

    }

    public boolean actualizar(Cliente objeto, int idCliente) {
        System.out.println("metodo actualizar");
        boolean respuesta = false;
        Connection cn = conexion.conectar();
        try {
            PreparedStatement consulta = (PreparedStatement) cn.prepareStatement("update tb_cliente set nombre = ?, apellido = ?, dni = ?, celular = ?, domicilio = ? where idCliente = '" + idCliente + "'");
            consulta.setString(1, objeto.getNombre());
            consulta.setString(2, objeto.getApellido());
            consulta.setLong(3, objeto.getDni());
            consulta.setString(4, objeto.getCelular());

            consulta.setString(5, objeto.getDomicilio());

            if (consulta.executeUpdate() > 0) {
                System.out.println("entra al if");
                respuesta = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al actualizar informacion" + e.getMessage());
        }

        return respuesta;
    }

    public boolean eliminar(int idCliente) {
        boolean respuesta = false;
        Connection cn = conexion.conectar();

        try {

            PreparedStatement consulta = (PreparedStatement) cn.prepareStatement("delete from tb_cliente where idCliente = '" + idCliente + "'");
            consulta.executeUpdate();

            if (consulta.executeUpdate() > 0) {

                respuesta = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al eliminar cliente: " + e);
        }
        return respuesta;
    }
}
