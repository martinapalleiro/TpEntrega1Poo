package modelo.DAOSS;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import conexion.conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Entitys.Productos;

public class DaoProductos {

    public boolean guardar(Productos producto) {

        boolean respuesta = false;
        Connection cn = (Connection) conexion.conectar();

        try {
            PreparedStatement consulta = (PreparedStatement) cn.prepareStatement("INSERT INTO tb_productos  VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

            consulta.setInt(1, producto.getIdProducto());
            consulta.setString(2, producto.getNombre());
            consulta.setString(3, producto.getDescripcion());
            consulta.setInt(4, producto.getStock());
            consulta.setDouble(5, producto.getValor());
            consulta.setInt(6, (int) (producto.getIdCategoria()));
            consulta.setDouble(7, producto.getPorcentajeIva());
            consulta.setInt(8, 1);

            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();

        } catch (SQLException e) {
            System.out.println("Error al guardar producto: " + e.getMessage());
        }
        return respuesta;

    }

    public List<String> cargarCategorias() {
        List<String> categorias = new ArrayList<>();
        String sql = "SELECT * FROM tb_categorias;";

        try (Connection cn = (Connection) conexion.conectar(); Statement st = (Statement) cn.createStatement(); ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                categorias.add(rs.getString("descripcion"));
            }
        } catch (SQLException e) {
            System.out.println("¡Error al cargar categoria! " + e);
        }
        return categorias;
    }

    public boolean existeProducto(String nombre) {

        boolean respuesta = false;
        String sql = "select idProductos from tb_productos where nombre = '" + nombre + "'";
        Statement st;

        try {
            Connection cn = (Connection) conexion.conectar();
            st = (Statement) cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                respuesta = true;
            }

        } catch (SQLException e) {
            System.out.println("Error en: " + e);
        }
        return respuesta;
    }

    public int idCategoria(String categ) {

        int id = 0;
        String sql = "select * from tb_categorias where descripcion ='" + categ + "'";
        try (Connection cn = (Connection) conexion.conectar(); Statement st = (Statement) cn.createStatement(); ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                id = rs.getInt("idCategoria");
            }
        } catch (SQLException e) {
            System.out.println("¡Error al cargar categoria! " + e);
        }
        return id;
    }

    public String nombreCategoria(int id) {
        String nombre = "";
        String sql = "select * from tb_categorias where idCategoria ='" + id + "'";
        try (Connection cn = (Connection) conexion.conectar(); Statement st = (Statement) cn.createStatement(); ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                nombre = rs.getString("descripcion");
            }
        } catch (SQLException e) {
            System.out.println("¡Error al cargar categoria! " + e);
        }
        return nombre;
    }

    public ArrayList<Productos> CargarProductos() {

        ArrayList<Productos> productos = new ArrayList();
        String sql = "select * from tb_productos;";
        try {
            Connection con = (Connection) conexion.conectar();
            Statement st = (Statement) con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                Productos prod = new Productos();
                prod.setIdProducto(rs.getInt("idProductos"));
                prod.setNombre(rs.getString("nombre"));
                prod.setStock(rs.getInt("stock"));
                prod.setValor(rs.getDouble("precio"));
                prod.setPorcentajeIva(rs.getDouble("porcentajeIva"));
                prod.setDescripcion(rs.getString("descripcion"));
                prod.setIdCategoria(rs.getInt("Idcategoria"));

                productos.add(prod);

            }

        } catch (SQLException e) {
            System.out.println("Error al cargar tabla productos " + e);
        }
        return productos;
    }

    public Productos EnviarDatosProd(int idProducto) {

        Productos prod = new Productos();
        try {
            Connection con = (Connection) conexion.conectar();
            PreparedStatement pst = (PreparedStatement) con.prepareStatement("SELECT * FROM tb_productos WHERE idProductos = ?");
            pst.setInt(1, idProducto);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                prod.setIdProducto(rs.getInt("idProductos"));
                prod.setNombre(rs.getString("nombre"));
                prod.setStock(rs.getInt("stock"));
                prod.setValor(rs.getDouble("precio"));
                prod.setPorcentajeIva(rs.getDouble("porcentajeIva"));
                prod.setDescripcion(rs.getString("descripcion"));
                prod.setIdCategoria(rs.getInt("Idcategoria"));
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener producto: " + e);
        }
        return prod;

    }

    public boolean actualizar(Productos producto, int idProducto) {
        String sql = "UPDATE tb_productos SET nombre=?, stock=?, precio = ?, porcentajeIva = ?, descripcion=?, Idcategoria=? WHERE idProductos = ?";
        try (Connection cn = (Connection) conexion.conectar(); PreparedStatement pst = (PreparedStatement) cn.prepareStatement(sql)) {
            pst.setString(1, producto.getNombre());
            pst.setInt(2, producto.getStock());
            pst.setDouble(3, producto.getValor());
            pst.setDouble(4, producto.getPorcentajeIva());
            pst.setString(5, producto.getDescripcion());
            pst.setInt(6, producto.getIdCategoria());
            pst.setInt(7, idProducto); 

            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al actualizar: " + e);
            return false;
        }
    }

    public boolean eliminarProducto(int id) {
        boolean respuesta = false;
        java.sql.Connection cn = (java.sql.Connection) conexion.conectar();
        try {
            PreparedStatement consulta = (PreparedStatement) cn.prepareStatement("delete from tb_productos where idProductos='" + id + "'");
            consulta.executeUpdate();
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al eliminar producto " + e);

        }
        return respuesta;

    }

    public List<String> cargarComboProductos() {
        List<String> prods = new ArrayList<>();
        String sql = "SELECT * FROM tb_productos;";

        try (Connection cn = (Connection) conexion.conectar(); Statement st = (Statement) cn.createStatement(); ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                prods.add(rs.getString("nombre"));
            }
        } catch (SQLException e) {
            System.out.println("¡Error al cargar productos! " + e);
        }
        return prods;
    }

    public int traerStock(String prod) {
        int stock = 0;
        String sql = "SELECT * FROM tb_productos where nombre='" + prod + "'";

        try (Connection cn = (Connection) conexion.conectar(); Statement st = (Statement) cn.createStatement(); ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                stock = rs.getInt("stock");
            }
        } catch (SQLException e) {
            System.out.println("¡Error al obtener stock! " + e);
        }
        return stock;
    }

    public int traerIdProd(String prod) {
        int id = 0;
        String sql = "SELECT * FROM tb_productos where nombre='" + prod + "'";

        try (Connection cn = (Connection) conexion.conectar(); Statement st = (Statement) cn.createStatement(); ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                id = rs.getInt("idProductos");
            }
        } catch (SQLException e) {
            System.out.println("¡Error al obtener stock! " + e);
        }
        return id;
    }

    public boolean ActualizarStock(Productos producto, int idProducto) {

        String sql = "UPDATE tb_productos SET stock = ? WHERE idProductos = ?";
        try (Connection cn = (Connection) conexion.conectar(); PreparedStatement pst = (PreparedStatement) cn.prepareStatement(sql)) {

            pst.setInt(1, producto.getStock());
            pst.setInt(2, idProducto);

            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al actualizar stock: " + e);
            return false;
        }
    }
}
