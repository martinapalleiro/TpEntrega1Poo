package modelo.DAOSS;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import conexion.conexion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import modelo.Entitys.Usuario;

public class DaoUsuario {

    public static boolean guardarUsuario(Usuario objeto) {
        boolean respuesta = false;
        Connection cn = (Connection) conexion.conectar();
        try {
            PreparedStatement consulta = (PreparedStatement) cn.prepareStatement("insert into tb_usuario values (?,?,?,?,?,?,?,?,?,?)");
            consulta.setInt(1, 0);
            consulta.setString(2, objeto.getPuesto());
            consulta.setString(3, objeto.getNombre());
            consulta.setString(4, objeto.getApellido());
            consulta.setLong(5, objeto.getDni());
            consulta.setString(6, objeto.getCelular());
            consulta.setString(7, objeto.getDomicilio());
            consulta.setString(8, objeto.getUsuario());
            consulta.setString(9, objeto.getContra());
            consulta.setInt(10, objeto.getEstado());
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al guardar usuario" + e);
        }
        return respuesta;

    }

    public static boolean existeUsuario(String usuario) {
        boolean respuesta = false;
        String sql = "SELECT usuario FROM tb_usuario WHERE usuario=?";
        Statement st;
        try {
            java.sql.Connection cn = (java.sql.Connection) conexion.conectar();
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                respuesta = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar usuario" + e);
        }
        return respuesta;
    }

    public static boolean iniciarSesionDao(Usuario objeto) {
        boolean respuesta = false;
        java.sql.Connection cn = (java.sql.Connection) conexion.conectar();
        String sql = "select  puesto, usuario, contra from tb_usuario where usuario='" + objeto.getUsuario() + "'and contra='" + objeto.getContra() + "'";
        Statement st;
        try {

            st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                respuesta = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al Iniciar Sesion ");
            JOptionPane.showMessageDialog(null, "Error al Iniciar Sesion");
        }
        return respuesta;
    }

    public static boolean actualizarUsuario(Usuario objeto, int idUsuario) {
        boolean respuesta = false;
        java.sql.Connection cn = conexion.conectar();
        PreparedStatement consulta = null;

        try {
            consulta = (PreparedStatement) cn.prepareStatement(
                    "UPDATE tb_usuario SET puesto=?, nombre=?, apellido=?, dni=?, celular=?, domicilio=?, usuario=?, contra=?, estado=? WHERE idUsuario=?"
            );

            consulta.setString(1, objeto.getPuesto());
            consulta.setString(2, objeto.getNombre());
            consulta.setString(3, objeto.getApellido());
            consulta.setLong(4, objeto.getDni());
            consulta.setString(5, objeto.getCelular());
            consulta.setString(6, objeto.getDomicilio());
            consulta.setString(7, objeto.getUsuario());
            consulta.setString(8, objeto.getContra());
            consulta.setInt(9, objeto.getEstado());
            consulta.setInt(10, idUsuario);

            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar usuario: " + e);
        } finally {
            try {

                if (consulta != null) {
                    consulta.close();
                }
                if (cn != null) {
                    cn.close();
                }
            } catch (SQLException e) {
                System.out.println("Error al cerrar recursos: " + e);
            }
        }

        return respuesta;
    }

    public static boolean eliminarUsuario(int id) {
        boolean respuesta = false;
        java.sql.Connection cn = (java.sql.Connection) conexion.conectar();
        try {
            PreparedStatement consulta = (PreparedStatement) cn.prepareStatement("delete from tb_usuario where idUsuario='" + id + "'");
            consulta.executeUpdate();
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al eliminar usuario " + e);

        }
        return respuesta;

    }

    public static List<Usuario> obtenerTodos() {
        List<Usuario> usuarios = new ArrayList<>();
        Connection con = (Connection) conexion.conectar();
        String sql = "SELECT * FROM tb_usuario";
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setId(rs.getInt("idUsuario")); 
                usuario.setPuesto(rs.getString("puesto"));
                usuario.setNombre(rs.getString("nombre"));
                usuario.setApellido(rs.getString("apellido"));
                usuario.setDni(rs.getLong("dni"));
                usuario.setCelular(rs.getString("celular"));
                usuario.setDomicilio(rs.getString("domicilio"));
                usuario.setUsuario(rs.getString("usuario"));
                usuarios.add(usuario);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println("Error al obtener usuarios: " + e);
        }
        return usuarios;
    }

    public static Usuario obtenerUsuarioPorId(int id) {
        Usuario usuario = null;
        Connection con = (Connection) conexion.conectar();
        String sql = "SELECT * FROM tb_usuario WHERE idUsuario = ?";
        try {
            PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                usuario = new Usuario();
                usuario.setId(rs.getInt("idUsuario")); 
                usuario.setPuesto(rs.getString("puesto"));
                usuario.setNombre(rs.getString("nombre"));
                usuario.setApellido(rs.getString("apellido"));
                usuario.setDni(rs.getLong("dni"));
                usuario.setCelular(rs.getString("celular"));
                usuario.setDomicilio(rs.getString("domicilio"));
                usuario.setUsuario(rs.getString("usuario"));
            }
            con.close();
        } catch (SQLException e) {
            System.out.println("Error al obtener usuario por ID: " + e);
        }
        return usuario;
    }
    
}
