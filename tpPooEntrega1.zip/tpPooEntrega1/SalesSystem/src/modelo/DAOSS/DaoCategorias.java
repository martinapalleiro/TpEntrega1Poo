package modelo.DAOSS;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import conexion.conexion;
import modelo.Entitys.Categoria;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DaoCategorias {

    public static boolean guardarCategoria(Categoria objeto) {
        boolean respuesta = false;
        Connection cn = (Connection) conexion.conectar();
        try {
            PreparedStatement consulta = (PreparedStatement) cn.prepareStatement("insert into tb_categorias values (?,?,?)");
            consulta.setInt(1, 0);
            consulta.setString(2, objeto.getDescripcion());
            consulta.setInt(3, objeto.getEstado());
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al guardar Categoria" + e);
        }
        return respuesta;

    }

    public static boolean existeCategoria(String descripcionCategoria) {
        boolean respuesta = false;
        String sql = "SELECT descripcion FROM tb_categorias WHERE descripcion=?";
        Statement st;
        try {
            java.sql.Connection cn = (java.sql.Connection) conexion.conectar();
            st = (Statement) cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                respuesta = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar categoria" + e);
        }
        return respuesta;
    }

    public static boolean actualizarCategoria(Categoria objeto, int idCategoria) {
        boolean respuesta = false;
        java.sql.Connection cn = conexion.conectar();
        PreparedStatement consulta = null;

        try {
            consulta = (PreparedStatement) cn.prepareStatement(
                    "UPDATE tb_categorias SET descripcion=?, estado=? WHERE idCategoria=?"
            );

            consulta.setString(1, objeto.getDescripcion());
            consulta.setInt(2, objeto.getEstado());
            consulta.setInt(3, idCategoria);

            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar categoria: " + e);
        } finally {
            try {

                if (consulta != null) {
                    consulta.close();
                }
                if (cn != null) {
                    cn.close();
                }
            } catch (SQLException e) {
                System.out.println("Error al cerrar recursos: " + e);
            }
        }

        return respuesta;
    }

    public static boolean eliminarCategoria(int id) {
        boolean respuesta = false;
        java.sql.Connection cn = (java.sql.Connection) conexion.conectar();
        try {
            PreparedStatement consulta = (PreparedStatement) cn.prepareStatement("delete from tb_categorias where idCategoria='" + id + "'");
            consulta.executeUpdate();
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al eliminar categoria " + e);

        }
        return respuesta;

    }

    public static List<Categoria> obtenerTodos() {
        List<Categoria> categorias = new ArrayList<>();
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;

        try {
            con = (Connection) conexion.conectar();
            if (con == null) {
                System.out.println("Error: no se pudo establecer conexión a la base de datos.");
                return categorias;
            }

            String sql = "SELECT * FROM tb_categorias;";
            System.out.println("Ejecutando consulta: " + sql); // Imprimir consulta SQL
            st = (Statement) con.createStatement();
            rs = st.executeQuery(sql);

            while (rs.next()) {
                Categoria cate = new Categoria();
                cate.setIdCategoria(rs.getInt("idCategoria")); // Correcto
                cate.setDescripcion(rs.getString("descripcion")); // Cambiado a "descripcion"
                categorias.add(cate);
            }

        } catch (SQLException e) {
            System.out.println("Error al obtener categorías: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                System.out.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return categorias;
    }

    public static Categoria obtenerCategoriaPorId(int id) {
        Categoria cate = null;
        Connection con = (Connection) conexion.conectar();
        String sql = "SELECT * FROM tb_categorias WHERE idCategoria = ?";
        try {
            PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                cate = new Categoria();
                cate.setIdCategoria(rs.getInt("idCategoria"));
                cate.setDescripcion(rs.getString("Descripcion"));
            }
            con.close();
        } catch (SQLException e) {
            System.out.println("Error al obtener categoria por ID: " + e);
        }
        return cate;
    }

}
