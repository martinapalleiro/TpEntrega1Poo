package modelo.DAOSS;

import modelo.Entitys.detallePedido;
import modelo.Entitys.Productos;
import modelo.Entitys.Pedido;
import modelo.Entitys.Cliente;
import Controlador.ControllerPedidosDetalles;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import conexion.conexion;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import static modelo.DAOSS.DaoPedidos.iDColVar;
import static modelo.DAOSS.DaoPedidos.idPedidoRegistrado;

public class DaoPedidosDetalles {

    public List<String> cargarCliente() {
        List<String> clientes = new ArrayList<>();
        String sql = "SELECT CONCAT(nombre, ' ', apellido) AS cliente FROM tb_cliente";

        try (Connection cn = (Connection) conexion.conectar(); Statement st = (Statement) cn.createStatement(); ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                clientes.add(rs.getString("cliente"));
            }
        } catch (SQLException e) {
            System.out.println("¡Error al cargar clientes: " + e);
        }
        return clientes;
    }

    public List<String> cargarProducto() {
        List<String> productos = new ArrayList<>();
        String sql = "SELECT nombre FROM tb_productos";

        try (Connection cn = (Connection) conexion.conectar(); Statement st = (Statement) cn.createStatement(); ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                productos.add(rs.getString("nombre"));
            }
        } catch (SQLException e) {
            System.out.println("¡Error al cargar productos: " + e);
        }
        return productos;
    }

    public static Productos obtenerDatosDelProducto(String nombreProducto, int cantidad) {
        Productos producto = null;
        String sql = "SELECT * FROM tb_productos WHERE nombre = ?";

        try (Connection cn = (Connection) conexion.conectar(); PreparedStatement pst = (PreparedStatement) cn.prepareStatement(sql)) {
            pst.setString(1, nombreProducto);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                producto = new Productos();
                producto.setIdProducto(rs.getInt("idProductos"));
                producto.setNombre(rs.getString("nombre"));
                producto.setStock(rs.getInt("stock"));
                producto.setValor(rs.getDouble("precio"));
                producto.setPorcentajeIva(rs.getInt("porcentajeIva"));

                double ivaCalculado = ControllerPedidosDetalles.calcularIva(producto.getValor(), (int) producto.getPorcentajeIva(), cantidad);
                producto.setIva(ivaCalculado);

                System.out.println("IVA calculado: " + producto.getIva());
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener datos del producto: " + e);
        }
        return producto;
    }

    public static int obtenerIdCliente(String nombreCompleto) {
        int idCliente = -1;
        String sql = "SELECT idCliente FROM tb_cliente WHERE CONCAT(nombre, ' ', apellido) = ?";

        try (Connection cn = (Connection) conexion.conectar(); PreparedStatement pst = (PreparedStatement) cn.prepareStatement(sql)) {
            pst.setString(1, nombreCompleto);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                idCliente = rs.getInt("idCliente");
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener id Cliente: " + e);
        }

        return idCliente;
    }

    public static boolean guardarPedido(Pedido objeto) {
        boolean respuesta = false;
        java.sql.Connection cn = (java.sql.Connection) conexion.conectar();
        try {
            PreparedStatement consulta = (PreparedStatement) cn.prepareStatement("insert into tb_ventas values (?,?,?,?,?)",
                    Statement.RETURN_GENERATED_KEYS);
            consulta.setInt(1, 0);
            consulta.setInt(2, objeto.getIdCliente());
            consulta.setDouble(3, objeto.getTotal());
            consulta.setString(4, objeto.getFechaVenta());
            consulta.setInt(5, objeto.getEstado());
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            ResultSet rs = consulta.getGeneratedKeys();
            while (rs.next()) {
                iDColVar = rs.getBigDecimal(1);
                idPedidoRegistrado = iDColVar.intValue();

            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al guardar Pedido " + e);
        }
        return respuesta;

    }

    public static boolean guardarDetalle(detallePedido objeto) {
        boolean respuesta = false;
        java.sql.Connection cn = (java.sql.Connection) conexion.conectar();
        try {
            PreparedStatement consulta = (PreparedStatement) cn.prepareStatement("insert into tb_detalleVentas values (?,?,?,?,?,?,?,?,?)");
            consulta.setInt(1, 0);
            consulta.setInt(2, idPedidoRegistrado);
            consulta.setInt(3, objeto.getIdProducto());
            consulta.setInt(4, objeto.getCantidad());
            consulta.setDouble(5, objeto.getPrecioUnitario());
            consulta.setDouble(6, objeto.getSubtotal());
            consulta.setDouble(7, objeto.getIva());
            consulta.setDouble(8, objeto.getTotal());
            consulta.setInt(9, objeto.getEstado());
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al guardar los detalles de pedido" + e);
        }
        return respuesta;

    }

    public static void restarStock(int idProducto, int cantidad) {
        try (Connection cn = (Connection) conexion.conectar()) {

            String sqlSelect = "SELECT stock FROM tb_productos WHERE idProductos = ?";
            try (PreparedStatement pst = (PreparedStatement) cn.prepareStatement(sqlSelect)) {
                pst.setInt(1, idProducto);
                ResultSet rs = pst.executeQuery();

                if (rs.next()) {
                    int stockActual = rs.getInt("stock");
                    int stockNuevo = stockActual - cantidad;

                    if (stockNuevo >= 0) {
                        String sqlUpdate = "UPDATE tb_productos SET stock = ? WHERE idProductos = ?";
                        try (PreparedStatement pstUpdate = (PreparedStatement) cn.prepareStatement(sqlUpdate)) {
                            pstUpdate.setInt(1, stockNuevo);
                            pstUpdate.setInt(2, idProducto);
                            pstUpdate.executeUpdate();
                        }
                    } else {
                        System.out.println("No hay suficiente stock para realizar esta operación.");
                    }
                } else {
                    System.out.println("Producto no encontrado.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al restar stock: " + e.getMessage());
        }
    }

    public static Cliente buscarClientePorDNI(String dni) {
        Connection cn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Cliente cliente = null;

        try {
            cn = (Connection) conexion.conectar();
            String sql = "SELECT nombre, apellido, dni FROM tb_cliente WHERE dni = ?";
            ps = (PreparedStatement) cn.prepareStatement(sql);
            ps.setString(1, dni);
            rs = ps.executeQuery();

            if (rs.next()) {
                String nombre = rs.getString("nombre");
                String apellido = rs.getString("apellido");
                long dniCliente = rs.getLong("dni");
                cliente = new Cliente(0, 0, nombre, apellido, dniCliente, "", "");
            }
        } catch (SQLException e) {
            System.out.println("Error al buscar cliente: " + e);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (cn != null) {
                    cn.close();
                }
            } catch (SQLException e) {
                System.out.println("Error al cerrar recursos: " + e);
            }
        }

        return cliente;
    }

    public static List<Map<String, Object>> CargarHistorial(String fechaInicio, String fechaFin) {
        List<Map<String, Object>> historialVentas = new ArrayList<>();
        String sql = "SELECT v.fechaVenta, \n"
                + "       CONCAT(c.nombre, ' ', c.apellido) AS cliente, \n"
                + "       v.Total  \n"
                + "FROM tb_ventas v \n"
                + "JOIN tb_cliente c ON v.idCliente = c.idCliente \n"
                + "WHERE v.fechaVenta BETWEEN ? AND ?\n"
                + "ORDER BY v.fechaVenta ASC;";

        try (Connection con = (Connection) conexion.conectar(); PreparedStatement ps = (PreparedStatement) con.prepareStatement(sql)) {

            ps.setString(1, fechaInicio);
            ps.setString(2, fechaFin);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> row = new HashMap<>();
                    row.put("fechaVenta", rs.getDate("fechaVenta"));
                    row.put("nombreCliente", rs.getString("cliente")); // Usar alias "cliente"
                    row.put("total", rs.getString("v.Total")); // Usar alias "cantidad"

                    historialVentas.add(row);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al cargar historial: " + e);
        }
        return historialVentas;
    }

}
