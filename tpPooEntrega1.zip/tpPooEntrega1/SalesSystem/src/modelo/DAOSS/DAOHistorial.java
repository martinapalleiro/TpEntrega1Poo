
package modelo.DAOSS;


public class DAOHistorial {
    
}
