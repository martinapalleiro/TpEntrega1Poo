
package sistemadeventas;

public class SistemaDeVentas {

    public static void main(String[] args) {
        
        
    }
    
}
