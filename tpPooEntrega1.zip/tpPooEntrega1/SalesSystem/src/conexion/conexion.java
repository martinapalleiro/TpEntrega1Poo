package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class conexion {

    //conexion local
    public static Connection conectar() {
        try {
            Connection cn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/bd_sistemaVentas", "root", "2236010119");

            return cn;
        } catch (SQLException e) {
            System.out.println("Error en la conexion local" + e);
        }
        return null;
    }
}
